function joinCheck() {
	var idBox = document.joinForm.sm_id;
	var pwBox = document.joinForm.sm_pw;
	var pwnBox = document.joinForm.sm_pwn;
	var nameBox = document.joinForm.sm_name;
	var imgBox = document.joinForm.sm_img;
	var addr1Box = document.joinForm.sm_addr1;
	var addr2Box = document.joinForm.sm_addr2;
	var addr3Box = document.joinForm.sm_addr3;
	if (isEmpty(idBox) || lessThan(idBox, 2) || containsHS(idBox) || $("#joinLoginOK").css("color") == "rgb(255, 0, 0)") {
		alert("ID 확인");		
		idBox.value = "";
		idBox.focus();
		$("#joinLoginOK").css("color","#263238").text("ID입력");
		return false;
	} else if (isEmpty(pwBox) || lessThan(pwBox, 2) || containsHS(pwBox)
			|| notContains(pwBox, "1234567890")) {
		alert("pw 확인");
		pwBox.value = "";
		pwBox.focus();
		return false;
	} else if (isEmpty(pwnBox) || notEquals(pwBox, pwnBox)) {
		alert("pw확인 확인");
		pwnBox.value = "";
		pwnBox.focus();
		return false;
	} else if (isEmpty(nameBox)) {
		alert("이름 확인");
		nameBox.value = "";
		nameBox.focus();
		return false;
	} else if (isEmpty(addr1Box) || isNotNumber(addr1Box)) {
		alert("우편번호 확인");
		addr1Box.value = "";
		addr1Box.focus();
		return false;
	} else if (isEmpty(addr2Box)) {
		alert("주소 확인");
		addr2Box.value = "";
		addr2Box.focus();
		return false;
	} else if (isEmpty(addr3Box)) {
		alert("상제주소 확인");
		addr3Box.value = "";
		addr3Box.focus();
		return false;
	} else if (isEmpty(imgBox)) {

		if (confirm("사진 없이 등록할꺼?")) {
			return true;
		}

		return false;
	} else if ((isNotType(imgBox, "png") && isNotType(imgBox, "gif")
			&& isNotType(imgBox, "bmp") && isNotType(imgBox, "jpg") && isNotType(
			imgBox, "jpeg"))) {
		alert("사진 확인");
		imgBox.value = "";
		imgBox.focus();
		return false;
	}
	return true;
}
function membershipUpdateCheck() {
	var idBox = document.membershipForm.sm_id;
	var pwBox = document.membershipForm.sm_pw;
	var pwnBox = document.membershipForm.sm_pwn;
	var nameBox = document.membershipForm.sm_name;
	var imgBox = document.membershipForm.sm_img;
	var addr1Box = document.membershipForm.sm_addr1;
	var addr2Box = document.membershipForm.sm_addr2;
	var addr3Box = document.membershipForm.sm_addr3;
	if (isEmpty(idBox) || lessThan(idBox, 2) || containsHS(idBox)) {
		alert("ID 확인");
		idBox.value = "";
		idBox.focus();
		return false;
	} else if (isEmpty(pwBox) || lessThan(pwBox, 2) || containsHS(pwBox)
			|| notContains(pwBox, "1234567890")) {
		alert("pw 확인");
		pwBox.value = "";
		pwBox.focus();
		return false;
	} else if (isEmpty(pwnBox) || notEquals(pwBox, pwnBox)) {
		alert("pw확인 확인");
		pwnBox.value = "";
		pwnBox.focus();
		return false;
	} else if (isEmpty(nameBox)) {
		alert("이름 확인");
		nameBox.value = "";
		nameBox.focus();
		return false;
	} else if (isEmpty(addr1Box) || isNotNumber(addr1Box)) {
		alert("우편번호 확인");
		addr1Box.value = "";
		addr1Box.focus();
		return false;
	} else if (isEmpty(addr2Box)) {
		alert("주소 확인");
		addr2Box.value = "";
		addr2Box.focus();
		return false;
	} else if (isEmpty(addr3Box)) {
		alert("상제주소 확인");
		addr3Box.value = "";
		addr3Box.focus();
		return false;
	} else if (isEmpty(imgBox)) {

		if (confirm("사진 없이 등록할꺼?")) {
			return true;
		}

		return false;
	} else if ((isNotType(imgBox, "png") && isNotType(imgBox, "gif")
			&& isNotType(imgBox, "bmp") && isNotType(imgBox, "jpg") && isNotType(
			imgBox, "jpeg"))) {
		alert("사진 확인");
		imgBox.value = "";
		imgBox.focus();
		return false;
	}
	return true;
}

function loginCheck() {
	var idBox = document.loginForm.sm_id;
	var pwBox = document.loginForm.sm_pw;

	if (isEmpty(idBox) || containsHS(idBox)) {
		alert("ID Ȯ��");
		idBox.value = "";
		idBox.focus();
		return false;
	} else if (isEmpty(pwBox) || containsHS(pwBox)) {
		alert("pw Ȯ��");
		pwBox.value = "";
		pwBox.focus();
		return false;
	}

	return true;
}
function txtCheck() {
	var txtBox = document.txtForm.st_txt;
	var pBox = document.txtForm.st_photo;

	if (isEmpty(txtBox)) {
		alert("내용을 쓰시오");
		txtBox.value = "";
		txtBox.focus();
		return false;
	} else if (isEmpty(pBox)) {

		return true;

	} else if ((isNotType(pBox, "png") && isNotType(pBox, "gif")
			&& isNotType(pBox, "bmp") && isNotType(pBox, "jpg") && isNotType(
			pBox, "jpeg"))) {
		alert("사진 확인");
		pBox.value = "";
		pBox.focus();
		return false;
	}

	return true;
}
function searchCheck() {
	var cBox = document.searchForm.st_content;

	if (isEmpty(cBox)) {
		alert("내용을 쓰시오");
		cBox.value = "";
		cBox.focus();
		return false;
	}

	return true;
}
function dataCheck() {
	var titleBox = document.dataForm.sf_title;
	var fileBox = document.dataForm.sf_file;

	if (isEmpty(titleBox)) {
		alert("제목 확인");
		titleBox.value = "";
		titleBox.focus();
		return false;
	} else if (isEmpty(fileBox)) {
		alert("파일 확인");
		fileBox.value = "";
		fileBox.focus();
		return false;
	}

	return true;
}
function updateCheck() {
	var titleBox = document.dataUpdateForm.sf_title;
	var fileBox = document.dataUpdateForm.sf_file;

	if (isEmpty(titleBox)) {
		alert("제목 확인");
		titleBox.value = "";
		titleBox.focus();
		return false;
	}

	return true;
}

function commentCheck(sss) {
	var tBox = sss.sc_txt;

	if (isEmpty(tBox)) {
		alert("������ ������");
		tBox.value = "";
		tBox.focus();
		return false;
	}

	return true;
}

function connectIdCheckEvent() {
	$("#sm_id").keyup(function() {
		var id = $(this).val();
		$.ajax({
			url : "member.id.check" ,
			data : {sm_id:id}, // {파라메터명:값, 파라메터명:값, ....}
			success: function(data) {
				if (id.length == 0) {
					$("#joinLoginOK").css("color","#263238").text("ID입력");
					
				}else if (id.length == 1 ) {
					$("#joinLoginOK").css("color","red").text("1개이상 입력");
					
				}else if ($(data).find("member").length == 1) {
					$("#joinLoginOK").css("color","red").text("중복");
					
				}else {
					$("#joinLoginOK").css("color","#263238").text("OK");
				}
			}
		});
	});
}
function followingCheck() {
	
		
		var f_sm_id = $("#f_sm_id").val();
		$.ajax({
			url : "page.follow",
			data : {jsf_followingid : f_sm_id},
			success: function(data) {
		
				
				if ($(data).find("follow").length != 0) {
					$("#following").empty();
					var followingCount = $(data).find("follow").length;
					
					$("#following").text("Following("+followingCount+")");				
				} else {
					$("#following").empty();
					$("#following").text("Following(0)");
				}
				
			}
			
		});
	
}
function follower() {
	
		var f_sm_id = $("#f_sm_id").val();
		$.ajax({
			url : "page.follower",
			data : {jsf_followerid : f_sm_id},
			success: function(data) {
			
				
					$("#follower").empty();
					
					var followerCount = $(data).find("follow").length;
					
					$("#follower").text("Follower("+followerCount+")");				
				
				
			}
			
		});
	
}

function followerCheck() {
	
	var sm_id = $(".sm_id").val();
	var f_sm_id = $(".f_sm_id").val();
	$.ajax({
		url : "page.follower.check",
		data : {jsf_followingid : sm_id,jsf_followerid : f_sm_id},
		success: function(data) {
			
			if ($(data).find("follow").length == 1) {
				
				$(".followerTd").css("border","red solid 2px");
				checkForHash();
				
				
			}else {
				
				$(".followerTd").css("border","black solid 2px");
				checkForHash();
			}
			
		}
		
	});
	
}

function followClick() {
		
		 var currentPage = "";
		$(".followerTd").click(function() {
			if ($(".followerTd").css("border") == "2px solid rgb(255, 0, 0)") {
				
			var sm_id = $(".sm_id").val();
			var f_sm_id = $(".f_sm_id").val();
			$.ajax({
				url : "page.follower.delete",
				data : {jsf_followingid : sm_id,jsf_followerid : f_sm_id},
				success: function(data) {
					
					follower();
				}
				
			});
			$(".followerTd").css("border","black solid 2px");
			currentPage = "black solid 2px";
	        document.location.hash = "#" + currentPage;
	        
			
			}else {
				
				var sm_id = $(".sm_id").val();
				var f_sm_id = $(".f_sm_id").val();
				$.ajax({
					url : "page.follower.reg",
					data : {jsf_followingid : sm_id,jsf_followerid : f_sm_id},				
					success: function(data) {
						follower();
					}
					
				});
				
				$(".followerTd").css("border","red solid 2px");
				currentPage = "red solid 2px";
				
				document.location.hash = "#" + currentPage;
			}
			
		})
}

function checkForHash() {
    if(document.location.hash){
        var HashLocationName = document.location.hash;
        HashLocationName = HashLocationName.replace("#","").replace("%20"," ").replace("%202"," 2");
       
        $(".followerTd").css("border", HashLocationName);
        
    } 
}






	