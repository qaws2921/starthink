
var login_sm_id;
function seachMemberShow() {
	var page;
	login_sm_id = $("#et_login_hm_id").val();

	page = 1;
	
	seachMember(page);
	
	
	$(document).on("click",".gogo1",function(){
		page -= 1;
		seachMember(page);
	});

	$(document).on("click",".gogo2",function(){
		page += 1;
		seachMember(page);
	});


}
////////////////////////////////
function seachTeaBagShow() {
	var page;
	login_sm_id = $("#et_login_hm_id").val();
	
	page = 1;
	
	seachTeabag(page);
	
	
	$(document).on("click",".gogo12",function(){
		page -= 1;
		seachTeabag(page);
	});
	
	$(document).on("click",".gogo22",function(){
		page += 1;
		seachTeabag(page);
	});
	
	
}
///////////////////////////////
function a() {
	alert( $("#etseach").val());
	alert( $("#et_login_hm_id").val());
}

function seachMember(page) {
	var seach = $("#etseach").val();
	$("#ttd").empty();
	var teaTable2 = $("<table></table>").attr("id","teaTable2");
	var teaTr1 = $("<tr></tr>");

	var teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("Tea(0)");
	teaTr1.append(teaNameTd);
	teaTable2.append(teaTr1);
	$("#ttd").append(teaTable2);
	$.getJSON("seach.go.member?page="+page+"&etseach="+seach,function(data){
		$.getJSON("seach.go.member.count?etseach="+seach,function(data2){
		$("#ttd").empty();
		teaTable2 = $("<table></table>").attr("id","teaTable2");
		teaTr1 = $("<tr></tr>");
		
		teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("Tea("+data2+")");
		teaTr1.append(teaNameTd);
		///////////////////////////////////////
		
		var teaTr2 = $("<tr></tr>");
		var gogo1 = $("<span></span>").attr("class","gogo1").text("◀");
		if (page == 1) {
			gogo1.text("");
		}
		var memberPage1 = $("<td></td>").attr("id","memberPage1").append(gogo1);
		
		teaTr2.append(memberPage1);
		if (data.member.length == 4) {
			
			for (var i = 0; i < 4; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
		}else if (data.member.length == 3) {
			for (var i = 0; i < 3; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
			seachMemberBlockMake(teaTr2,teaTable2);
		}else if (data.member.length == 2) {
			for (var i = 0; i < 2; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
			for (var i = 0; i < 2; i++) {
				seachMemberBlockMake(teaTr2,teaTable2);
			}
		}else if (data.member.length == 1) {
			for (var i = 0; i < 1; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			for (var i = 0; i < 3; i++) {
				seachMemberBlockMake(teaTr2,teaTable2);
			}
		}
		
		var gogo2 = $("<span></span>").attr("class","gogo2").text("▶");
		if (page*4 >= data2) {
			gogo2.text("");
		}
		var memberPage2 = $("<td></td>").attr("id","memberPage2").append(gogo2);
		
		
		
		teaTr2.append(memberPage2);
		teaTable2.append(teaTr1,teaTr2);
		
		
		$("#ttd").append(teaTable2);
		});
	});
}
function seachTeabag(page) {
	var seach = $("#etseach").val();
	$("#ttd2").empty();
	var teaTable2 = $("<table></table>").attr("id","teaTable2");
	var teaTr1 = $("<tr></tr>");
	
	var teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("TeaBag(0)");
	teaTr1.append(teaNameTd);
	teaTable2.append(teaTr1);
	$("#ttd2").append(teaTable2);
	$.getJSON("seach.go.teabag?page="+page+"&etseach="+seach,function(data){
		$.getJSON("seach.go.teabag.count?etseach="+seach,function(data2){
			$("#ttd2").empty();
			teaTable2 = $("<table></table>").attr("id","teaTable2");
			teaTr1 = $("<tr></tr>");
			
			teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("TeaBag("+data2+")");
			teaTr1.append(teaNameTd);
			///////////////////////////////////////
			
			var teaTr2 = $("<tr></tr>");
			var gogo1 = $("<span></span>").attr("class","gogo12").text("◀");
			if (page == 1) {
				gogo1.text("");
			}
			var memberPage1 = $("<td></td>").attr("id","memberPage1").append(gogo1);
			
			teaTr2.append(memberPage1);
			if (data.teabagSeach.length == 4) {
				
				for (var i = 0; i < 4; i++) {
					seachTeaBagMake(data.teabagSeach[i],teaTr2,teaTable2);				
				}
				
			}else if (data.teabagSeach.length == 3) {
				for (var i = 0; i < 3; i++) {
					seachTeaBagMake(data.teabagSeach[i],teaTr2,teaTable2);				
				}
				
				seachMemberBlockMake(teaTr2,teaTable2);
			}else if (data.teabagSeach.length == 2) {
				for (var i = 0; i < 2; i++) {
					seachTeaBagMake(data.teabagSeach[i],teaTr2,teaTable2);				
				}
				
				for (var i = 0; i < 2; i++) {
					seachMemberBlockMake(teaTr2,teaTable2);
				}
			}else if (data.teabagSeach.length == 1) {
				for (var i = 0; i < 1; i++) {
					seachTeaBagMake(data.teabagSeach[i],teaTr2,teaTable2);				
				}
				for (var i = 0; i < 3; i++) {
					seachMemberBlockMake(teaTr2,teaTable2);
				}
			}
			var gogo2 = $("<span></span>").attr("class","gogo22").text("▶");
			if (page*4 >= data2) {
				gogo2.text("");
			}
			var memberPage2 = $("<td></td>").attr("id","memberPage2").append(gogo2);
			
			
			
			teaTr2.append(memberPage2);
			teaTable2.append(teaTr1,teaTr2);
			
			
			$("#ttd2").append(teaTable2);
		});
	});
}


function seachMemberMake(member,teaTr2,teaTable2) {
	var teasTd = $("<td></td>").attr("align","center");
	if (member.hm_id == login_sm_id) {
		var memberSTable = $("<table></table>").attr("onclick","goMyPage('"+member.hm_nickname+"');").attr("class","memberSTable");
	}else {
		var memberSTable = $("<table></table>").attr("onclick","goPage('"+member.hm_nickname+"');").attr("class","memberSTable");
		
	}
	
	
	
//	var seachImg = $("<img></img>").attr("class","seachImg").attr("src","resources/img/member/"+member.hm_photo_front);
//	var aseachImg = $("<a></a>").attr("href","resources/memberImg/"+member.sm_img).append(seachImg);
	
	var divSeachImg = $("<div></div>").attr("class","divSeachImg").attr("style","background: url(resources/img/member/"+member.hm_photo_front+") center center no-repeat; background-size: cover;");
	
	
	//////////////////////////////////////////////////
	
	if (member.hm_selfIntroduction.length > 5) {
		
		var memberSTableNameSpan = $("<span></span>").attr("align","center").text(member.hm_selfIntroduction.substring(5, 0)+"...").attr("class","divSeachIntroduction");
	}else {
		var memberSTableNameSpan = $("<span></span>").attr("align","center").text(member.hm_selfIntroduction).attr("class","divSeachIntroduction");
		
	}
	
	var memberSTableIdDiv = $("<div></div>").attr("class","divSeachName").text(member.hm_nickname);

	
	var memberSTableImgTd = $("<td></td>").attr("align","center").append(divSeachImg,memberSTableIdDiv,memberSTableNameSpan);
	var memberSTableImgTr = $("<tr></tr>").append(memberSTableImgTd);
	///////////////////////////////////////////////
	
	
	memberSTable.append(memberSTableImgTr);
	
	teasTd.append(memberSTable);
	teaTr2.append(teasTd);
	teaTable2.append(teaTr2);
			
}
function seachTeaBagMake(teabagSeach,teaTr2,teaTable2) {
	var teasTd = $("<td></td>").attr("align","center");

	
	var memberSTable = $("<table></table>").attr("onclick","goTeabagPage('"+teabagSeach.ht_no+"');").attr("class","memberSTable");

	
	
	
//	var seachImg = $("<img></img>").attr("class","seachImg").attr("src","resources/img/member/"+member.hm_photo_front);
//	var aseachImg = $("<a></a>").attr("href","resources/memberImg/"+member.sm_img).append(seachImg);
	
	var divSeachImg = $("<div></div>").attr("class","divSeachImg").attr("style","background: url(resources/img/teabag/"+teabagSeach.ht_profilepic+") center center no-repeat; background-size: cover;");
	
	
	//////////////////////////////////////////////////
	
	
	///////////////////////////////////////////////
	
	var memberSTableIdDiv = $("<div></div>").attr("class","divSeachName").text(teabagSeach.ht_name).attr("class","divSeachName");
	var memberSTableNameSpan = $("<span></span>").attr("align","center").text(teabagSeach.ht_category).attr("class","divSeachIntroduction");

	
	
	var memberSTableImgTd = $("<td></td>").attr("align","center").append(divSeachImg,memberSTableIdDiv,memberSTableNameSpan);
	var memberSTableImgTr = $("<tr></tr>").append(memberSTableImgTd);
	
	memberSTable.append(memberSTableImgTr);
	
	teasTd.append(memberSTable);
	teaTr2.append(teasTd);
	teaTable2.append(teaTr2);
	
}

function seachMemberBlockMake(teaTr2,teaTable2) {
	
	var teasTd = $("<td></td>").attr("align","center");
	var memberSTable = $("<table></table>").attr("class","memberSTable2");
	

	var memberSTableImgTd = $("<td></td>").attr("align","center");
	var memberSTableImgTr = $("<tr></tr>").append(memberSTableImgTd);
	
	//////////////////////////////////////////////////
	
	var memberSTableIdTd = $("<td></td>").attr("align","center");
	var memberSTableIdTr = $("<tr></tr>").append(memberSTableIdTd);
	
	///////////////////////////////////////////////
	
	var memberSTableNameTd = $("<td></td>").attr("align","center");
	var memberSTableNameTr = $("<tr></tr>").append(memberSTableNameTd);
	
	memberSTable.append(memberSTableImgTr,memberSTableIdTr,memberSTableNameTr);
	
	teasTd.append(memberSTable);
	teaTr2.append(teasTd);
	teaTable2.append(teaTr2);
}


//////////////////////////////////////////////////////////////////////



function scrollShowSeach() {
	
	
	var pNo = 1;
	snsAllShowSeach(pNo);
	
	

	
	$(window).scroll(function() {
		var htmlHeight = $(document).height();
		var scrollBottom =$(window).scrollTop() + $(window).height();
		
		if (scrollBottom+1 >= htmlHeight) {
			pNo++;
			snsAllShowSeach(pNo);
			
			
		}
	});
}

function snsAllShowSeach(pNo) {
	login_sm_nickname = $("#login_sm_nickname").val();
	var seach = $("#etseach").val();
	var SNSSeachCountTd = $("#SNSSeachCountTd").text("SNS(0)");
	$.getJSON("seach.go.sns?page="+pNo+"&seach="+seach,function(data){
		$.getJSON("seach.sns.all?seach="+seach,function(data2){
		login_sm_id = $("#et_login_hm_id").val();
		SNSSeachCountTd.text("SNS("+data2+")");
		$.each(data.snsBeans,function(i1,s){
			snsShowShow(i1,s);
			//////////////////////////////////////
		});	
		
		
		
		});
	});
}
var login_sm_nickname
function snsReAllSeach() {
	login_sm_nickname = $("#login_sm_nickname").val();
	$(document).on("click",".snsRessA",function(){
		var hs_no = $(this).parent().find(".snsNoInput").val();
		var snsReTable = $(this).parent().parent().parent().find(".snsReTable");
		$(this).removeClass('snsRessA').text("댓글 3개 보기").attr("class","snsRessB");
		snsReTable.empty();
		$.getJSON("sns.Repl.ajax?hs_no="+hs_no,function(data){
			
			
			for (var z = 0; z < data.snsRepl.length; z++) {
				var snsReMainRepl = $("<span></span>").attr("class","snsReMainRepl");
				var snsreImg = $("<img>").attr("src","resources/img/member/"+data.snsRepl[z].hsr_img).attr("style","width: 30px;");
				var snsrenickname = $("<span></span>").html(data.snsRepl[z].hsr_hm_nickname+"&nbsp;");
				var snssm1 = $("<span></span>").attr("class","snssm1").attr("onclick","goYourPage();").append(snsreImg,snsrenickname);
				
				var snssm2 = $("<span></span>").text(data.snsRepl[z].hsr_txt);
				
				var snsDateYearre = data.snsRepl[z].hsr_date.year;
				var snsDatemonthValuere = data.snsRepl[z].hsr_date.monthValue;
				if (data.snsRepl[z].hsr_date.monthValue < 10) {
					snsDatemonthValuere = "0"+data.snsRepl[z].hsr_date.monthValue;
				}
				var snsDatedayOfMonthre = data.snsRepl[z].hsr_date.dayOfMonth;
				if (data.snsRepl[z].hsr_date.dayOfMonth < 10) {
					snsDatedayOfMonthre = "0"+data.snsRepl[z].hsr_date.dayOfMonth;
				}
				var snsDatehourre = data.snsRepl[z].hsr_date.hour;
				if (data.snsRepl[z].hsr_date.hour < 10) {
					snsDatehourre  = "0"+data.snsRepl[z].hsr_date.hour;
				}
				var snsDateminutere = data.snsRepl[z].hsr_date.minute;
				if (data.snsRepl[z].hsr_date.minute < 10) {
					snsDateminutere = "0"+data.snsRepl[z].hsr_date.minute;
				}
				var dateAllre = snsDateYearre+"/"+snsDatemonthValuere+"/"+snsDatedayOfMonthre+"/"+snsDatehourre+":"+snsDateminutere;
				
				var snssm3 = $("<span></span>").html(dateAllre+"&nbsp;").attr("style","color: #FAC03B; font-size: 6pt;");
				
				if (login_sm_nickname == data.snsRepl[z].hsr_hm_nickname) {
					var snsredelete = $("<img>").attr("src","resources/img/sns/snsdelete.png").attr("style","width: 15px;").attr("class","srDeleteImg");;
					var snssm5 = $("<input>").attr("class","srNoInput").attr("value",data.snsRepl[z].hsr_no).attr("type","hidden");
					var snssm4 = $("<span></span>").append(snsredelete,snssm5);
					
				}else {
					var snssm4 = $("<span></span>");	
				}
				var snsrebr = $("<br>");
				snsReMainRepl.append(snssm1,snssm2,snssm3,snssm4,snsrebr);
				snsReTable.prepend(snsReMainRepl);
				
			}
		});
	});
}

function snsReAll3Seach(){
	login_sm_nickname = $("#login_sm_nickname").val();
	$(document).on("click",".snsRessB",function(){
		var hs_no = $(this).parent().find(".snsNoInput").val();
		var snsReTable = $(this).parent().parent().parent().find(".snsReTable");
		$(this).removeClass('snsRessB').text("이전 댓글 보기").attr("class","snsRessA");
		snsReTable.empty();
		$.getJSON("sns.Repl3.ajax?hs_no="+hs_no,function(data){
			
			
			for (var z = 0; z < data.snsRepl.length; z++) {
				
				var snsReMainRepl = $("<span></span>").attr("class","snsReMainRepl");
				var snsreImg = $("<img>").attr("src","resources/img/member/"+data.snsRepl[z].hsr_img).attr("style","width: 30px;");
				var snsrenickname = $("<span></span>").html(data.snsRepl[z].hsr_hm_nickname+"&nbsp;");
				var snssm1 = $("<span></span>").attr("class","snssm1").attr("onclick","goYourPage();").append(snsreImg,snsrenickname);
				
				var snssm2 = $("<span></span>").text(data.snsRepl[z].hsr_txt);
				
				var snsDateYearre = data.snsRepl[z].hsr_date.year;
				var snsDatemonthValuere = data.snsRepl[z].hsr_date.monthValue;
				if (data.snsRepl[z].hsr_date.monthValue < 10) {
					snsDatemonthValuere = "0"+data.snsRepl[z].hsr_date.monthValue;
				}
				var snsDatedayOfMonthre = data.snsRepl[z].hsr_date.dayOfMonth;
				if (data.snsRepl[z].hsr_date.dayOfMonth < 10) {
					snsDatedayOfMonthre = "0"+data.snsRepl[z].hsr_date.dayOfMonth;
				}
				var snsDatehourre = data.snsRepl[z].hsr_date.hour;
				if (data.snsRepl[z].hsr_date.hour < 10) {
					snsDatehourre  = "0"+data.snsRepl[z].hsr_date.hour;
				}
				var snsDateminutere = data.snsRepl[z].hsr_date.minute;
				if (data.snsRepl[z].hsr_date.minute < 10) {
					snsDateminutere = "0"+data.snsRepl[z].hsr_date.minute;
				}
				var dateAllre = snsDateYearre+"/"+snsDatemonthValuere+"/"+snsDatedayOfMonthre+"/"+snsDatehourre+":"+snsDateminutere;
				
				var snssm3 = $("<span></span>").html(dateAllre+"&nbsp;").attr("style","color: #FAC03B; font-size: 6pt;");
				
				if (login_sm_nickname == data.snsRepl[z].hsr_hm_nickname) {
					var snsredelete = $("<img>").attr("src","resources/img/sns/snsdelete.png").attr("style","width: 15px;").attr("class","srDeleteImg");;
					var snssm5 = $("<input>").attr("class","srNoInput").attr("value",data.snsRepl[z].hsr_no).attr("type","hidden");
					var snssm4 = $("<span></span>").append(snsredelete,snssm5);
					
				}else {
					var snssm4 = $("<span></span>");	
				}
				var snsrebr = $("<br>");
				snsReMainRepl.append(snssm1,snssm2,snssm3,snssm4,snsrebr);
				snsReTable.prepend(snsReMainRepl);
			}
		});
	});
}


function hashSharpSeach() {
	$(document).on("click",".hs_txt2",function(){
		$(".hs_txt2").val("#");
	});
	$(document).on("click",".hs_txt3",function(){
		$(".hs_txt3").val("!");
	});
	
	$(".hs_txt2").keyup(function(e) {
		if (e.keyCode == "32") {
			var what = $(".hs_txt2").val();
			var what2 = what+"#";
			$(".hs_txt2").val(what2);
		}
		
		if (e.keyCode == "8") {
			if ($(".hs_txt2").val() == "") {
				$(".hs_txt2").val("#");
			}
		}
	});
	$(".hs_txt3").keyup(function(e) {
		if (e.keyCode == "32") {
			var what = $(".hs_txt3").val();
			var what2 = what+"!";
			$(".hs_txt3").val(what2);
		}
		
		if (e.keyCode == "8") {
			if ($(".hs_txt3").val() == "") {
				$(".hs_txt3").val("!");
			}
		}
	});
	
	
}

function hartImgClicSeach() {
	$(document).on("click",".heartImg",function(){
		var heartImg = $(this);
		var heartCount = $(this).parent().find(".heartCount");
		var st_no2 = $(this).parent().find(".snsHeartNoInput").val();
		var st_id = $(this).parent().find(".snsHeartIdInput").val();
		var le = 0;
		$.getJSON("hart.check.img?hs_no="+st_no2+"&hs_hm_id="+login_sm_id,function(data) {
			$.getJSON("hart.check?hs_no="+st_no2,function(data3) {
				le = data.hart.length;
				if (le >= 1) {	
					$.getJSON("hart.delete?hs_no="+st_no2+"&hs_hm_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length-1;
						heartImg.attr("class","heartImg").attr("src","resources/img/sns/heart.png");
						heartCount.empty();
						heartCount.text("("+num+")");
					});
				}else {
					$.getJSON("hart.reg?hs_no="+st_no2+"&hs_hm_id="+login_sm_id+"&hs_hm_id2="+login_sm_id+"&st_id="+st_id,function(data2) {
						
						var num = data3.hart.length+1;
						heartImg.attr("class","heartImg").attr("src","resources/img/sns/heartOk.png");
						heartCount.empty();
						heartCount.text("("+num+")");
					});
				}
			});
		});
	}); 
}