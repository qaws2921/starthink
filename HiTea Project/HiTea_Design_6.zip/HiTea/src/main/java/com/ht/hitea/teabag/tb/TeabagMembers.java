package com.ht.hitea.teabag.tb;

import java.util.List;

public class TeabagMembers {
	private List<TeabagMember> TeabagMember;
	
	public TeabagMembers() {
		// TODO Auto-generated constructor stub
	}

	public TeabagMembers(List<com.ht.hitea.teabag.tb.TeabagMember> teabagMember) {
		super();
		TeabagMember = teabagMember;
	}

	public List<TeabagMember> getTeabagMember() {
		return TeabagMember;
	}

	public void setTeabagMember(List<TeabagMember> teabagMember) {
		TeabagMember = teabagMember;
	}


	
}
