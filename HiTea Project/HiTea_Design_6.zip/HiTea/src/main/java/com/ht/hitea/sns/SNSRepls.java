package com.ht.hitea.sns;

import java.util.List;

public class SNSRepls {
	private List<SNSRepl> snsRepl;
	public SNSRepls() {
		// TODO Auto-generated constructor stub
	}
	public SNSRepls(List<SNSRepl> snsRepl) {
		super();
		this.snsRepl = snsRepl;
	}
	public List<SNSRepl> getSnsRepl() {
		return snsRepl;
	}
	public void setSnsRepl(List<SNSRepl> snsRepl) {
		this.snsRepl = snsRepl;
	}
	
}
