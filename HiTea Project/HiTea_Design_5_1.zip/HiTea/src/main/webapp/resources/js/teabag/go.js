function goAllTeabag() {
	location.href="site.teabag.home";
}
function goLeaveTeabag(tno) {
	if(confirm("티백을 탈퇴하시겠습니까?")){
		location.href="site.teabag.leave?ht_no="+tno;
	} else{
		return false;
	}
}
function goDeleteBBS(tno) {
	if(confirm("방명록을 삭제하시겠습니까?")){
		location.href="teabag.bbs.delete?hb_no="+tno;
	} else{
		return false;
	}
}
function goDeleteDR(no) {
	if(confirm("파일을 삭제하시겠습니까?")){
		location.href="teabag.dr.delete?hd_no="+no;
	} else{
		return false;
	}
}
function goPagePhoto(i) {
	url = "teabag.dr.pagePhoto?p="+i;
	tb_dataroom_getPhoto();
}
function goForceDeleteMember(htm_id) {
	if(confirm("강제탈퇴 시키겠습니까?")){
		location.href="teabag.member.forceDeleteMember?htm_id="+htm_id;
	} else{
		return false;
	}
}
function goDelegateMember(htm_id) {
	if(confirm("티백장을 위임 시키겠습니까?")){
		location.href="teabag.member.delegateMember?htm_id="+htm_id;
	} else{
		return false;
	}
}
function goPageFile(i) {
	url = "teabag.dr.pageFile?p="+i;
	tb_dataroom_getFile();
}
function goUpdateNotice() {
	var input = prompt('수정 내용을 입력하세요.');
	if(input != null){
		location.href="site.teabag.updateNotice?ht_notice="+input;		
	}else{
		return false;
	}
}

function goTeabagPage(no) {
	location.href="site.teabag.go?ht_no="+no;
}

function goDeleteTeabag() {
	if(confirm("티백 삭제하겠습니까?")){
		location.href="site.teabag.deleteTeabag";
	} else{
		return false;
	}
}
