package com.ht.hitea.teabag.tb.member;

import java.util.List;

public class JoinReqs {
	private List<JoinReq> joinreq;
	
	public JoinReqs() {
		// TODO Auto-generated constructor stub
	}

	public JoinReqs(List<JoinReq> joinreq) {
		super();
		this.joinreq = joinreq;
	}

	public List<JoinReq> getJoinreq() {
		return joinreq;
	}

	public void setJoinreq(List<JoinReq> joinreq) {
		this.joinreq = joinreq;
	}
	
	
	
	
}
