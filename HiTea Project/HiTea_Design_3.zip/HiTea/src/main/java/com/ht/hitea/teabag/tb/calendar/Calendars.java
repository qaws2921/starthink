package com.ht.hitea.teabag.tb.calendar;

import java.util.List;

public class Calendars {
	private List<Calendar> calendar;
	
	public Calendars() {
		// TODO Auto-generated constructor stub
	}

	public Calendars(List<Calendar> calendar) {
		super();
		this.calendar = calendar;
	}

	public List<Calendar> getCalendar() {
		return calendar;
	}

	public void setCalendar(List<Calendar> calendar) {
		this.calendar = calendar;
	}
	
	
}
