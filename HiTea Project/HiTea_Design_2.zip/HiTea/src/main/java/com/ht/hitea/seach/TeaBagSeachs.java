package com.ht.hitea.seach;

import java.util.List;

public class TeaBagSeachs {
	private List<TeaBagSeach> teabagSeach;
	public TeaBagSeachs() {
		// TODO Auto-generated constructor stub
	}
	public TeaBagSeachs(List<TeaBagSeach> teabagSeach) {
		super();
		this.teabagSeach = teabagSeach;
	}
	public List<TeaBagSeach> getTeabagSeach() {
		return teabagSeach;
	}
	public void setTeabagSeach(List<TeaBagSeach> teabagSeach) {
		this.teabagSeach = teabagSeach;
	}
	
	
}
