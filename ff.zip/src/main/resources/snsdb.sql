

create table hitea_sns(
	hs_no number(6) primary key,	
	hs_hm_nickname varchar2(8 char) not null,
	hs_txt varchar2(500 char) not null,	
	hs_txt2 varchar2(500 char) not null,
	hs_txt3 varchar2(500 char) not null,
	hs_photo_front varchar2(200 char) not null,
	hs_date date not null					
); 


create table hitea_sns_repl(
	hsr_no number(6) primary key,		
	hsr_hs_no number(6) not null,		
	hsr_hm_nickname varchar2(8 char) not null,	
	hsr_txt varchar2(200 char) not null,		
	hsr_date date not null,
	constraint hitea_sns_repl_haha foreign key(hsr_hs_no) references hitea_sns(hs_no) on delete cascade
);


create table hitea_files(
	hfile_no number(6) not null,
	hfile_img varchar2(500 char) not null,
	hfile_video varchar2(500 char) not null,
	constraint hitea_files_haha foreign key(hfile_no) references hitea_sns(hs_no) on delete cascade
);


select * from HITEA_SNS_REPL
select * from hitea_sns
select * from hitea_files

select * from (select rownum as rn, hsr_no, hsr_hs_no, hsr_hm_nickname, hsr_txt, hsr_date from (select * from hitea_sns_repl where hsr_hs_no = 43 order by hsr_date desc)) where rn >= 1 and rn <= 3 order by hsr_date desc
select * from hitea_files where hfile_no=43
