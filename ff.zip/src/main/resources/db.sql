------------- 티백

create table hitea_teabag(
	ht_no number(10) primary key,
	ht_name varchar2(15char) not null,
	ht_category varchar2(15char) not null,
	ht_date date not null,
	ht_leaderid varchar2(10char) not null,
	ht_profilepic varchar2(200char) not null,
	ht_bgpic varchar2(200char) not null,
	ht_introduce varchar2(100char) not null,
	ht_minage number(8) not null,
	ht_maxage number(8) not null,
	ht_count number(15) not null,
	ht_notice varchar2(200char) not null
);

delete from hitea_teabag

create table hitea_teabagmember(
	htm_id varchar2(10char) not null,
	htm_tno number(10) not null,
	htm_date varchar2(200char) not null,
	constraint band_member_terms foreign key (htm_tno) references hitea_teabag(ht_no) on delete cascade
);

insert into hitea_teabagmember values(
	'qwer',
	41,
	'2019-03-18'
);

delete from hitea_joinreq where hj_no = 1

update hitea_teabagmember set htm_date = '19-03-19' where htm_id = 'efgh';

select * from hitea_teabagmember where htm_tno = 63

update hitea_teabag set ht_leaderid = 'efgh' where ht_no = 41;

select * from hitea_teabag

select * from hitea_bbs, hitea_member where hb_id = hm_id and hb_tno = 41 order by hb_date desc

delete from hitea_dataroom where hd_no = 62

select * from hitea_pagenotice

create table hitea_bbs(
	hb_no number(15) not null,
	hb_id varchar2(10 char) not null,
	hb_content varchar2(200 char) not null,
	hb_date date not null,
	hb_tno number(15) not null,
	constraint hitea_bbs_term 
	foreign key(hb_tno) references hitea_teabag(ht_no)
	on delete cascade
);

create table hitea_joinreq(
	hj_no number(15) primary key,
	hj_id varchar2(20 char) not null,
	hj_tno number(10) not null,
	hj_date varchar2(20char) not null,
	constraint hitea_joinreq_term 
	foreign key(hj_tno) references hitea_teabag(ht_no)
	on delete cascade
);

create table hitea_pagenotice(
	hpn_no number(15) primary key,
	hpn_id varchar2(20char),
	hpn_tno number(10) not null,
	hpn_content varchar2(100char) not null,
	hpn_type varchar2(10char) not null,
	hpn_date varchar2(20char) not null,
	constraint hitea_pagenotice_term 
	foreign key(hpn_tno) references hitea_teabag(ht_no)
	on delete cascade
);


insert into hitea_pagenotice values(
	hitea_pagenotice_seq.nextval,
	
)


create sequence hitea_joinreq_seq;
create sequence hitea_teabag_seq;
create sequence hitea_notice_seq;
create sequence hitea_pagenotice_seq;

create table hitea_dataroom(
	hd_no number(15) primary key,
	hd_id varchar2(20char) not null,
	hd_title varchar2(20char) not null,
	hd_fname varchar2(200char) not null,
	hd_tno number(4) not null,
	hd_ftype varchar2(3char) not null,
	hd_date varchar2(200char) not null,
	constraint hitea_dataroom_term 
	foreign key(hd_tno) references hitea_teabag(ht_no)
	on delete cascade
);

select * from hitea_calendar where hc_tno = 63

delete from hitea_calendar where hc_no = 2 

create table hitea_calendar(
	hc_no number(15) primary key,
	hc_tno number(4) not null,
	hc_category varchar2(10char) not null, 
	hc_title varchar2(20char) not null,
	hc_content varchar2(200char) not null,
	hc_start varchar2(20char) not null,
	hc_end varchar2(20char) not null,
	constraint hitea_calendar_term 
	foreign key(hc_tno) references hitea_teabag(ht_no)
	on delete cascade
);


select * from (
select rownum as rn, htm_id, htm_tno, hm_photo_front, hm_nickname, htm_date from (
select * from hitea_teabagmember, hitea_member where htm_id = hm_id and htm_tno = 41 order by htm_date desc
)
) where rn >= 1 and rn <= 2 order by rn desc;

select * from hitea_joinreq where hj_no = 10;

select * from hitea_joinreq, hitea_member where hj_tno = 63 and hj_id = hm_id

select * from hitea_joinreq where hj_tno = 41

delete from hitea_joinreq

create sequence hitea_joinreq_seq;

select * from hitea_teabag where ht_leaderid = 'abcd' and ht_date = (
select max(ht_date) from hitea_teabag);

select * from hitea_teabagmember

select * from hitea_bbs, hitea_member where hb_id = hm_id and hb_tno = 41;

select * from hitea_teabagmember, hitea_member where htm_tno = 41

update hitea_bbs set hb_content='rse' where hb_no = 15

delete from hitea_dataroom

delete from hitea_bbs where hb_no = 15

alter table hitea_bbs
add constraint hitea_bbs_term 
		foreign key(hb_no) references hitea_teabag(ht_no)
		on delete cascade;

select * from (
select rownum as rn, hd_no, hd_id, hd_title, hd_fname, hd_tno, hd_ftype, hd_date from (
select * from hitea_dataroom where hd_tno = 41 and hd_ftype='p' order by hd_date
)
) where rn >= 1 and rn <= 2 order by rn desc;

select * from hitea_dataroom where hd_tno = 41

select * from (
select rownum as rn, hb_no, hb_id, hb_content, hb_date, hm_photo_front from (
select * from hitea_bbs, hitea_member where hb_id = hm_id and hb_tno=#{hb_tno} order by hb_date
)
) 
where rn &lt;= #{min} and rn &gt;= #{max} order by rn desc

select * from hitea_bbs, hitea_member where hb_id = hm_id and hb_tno = 41 order by hb_date desc

select count(*) from hitea_dataroom where hd_tno = 41 and hd_ftype='p'
--------------메신저 (아직 실행 안 함)

create table hitea_messenger_list(
  hmsl_no number(10) primary key, 
  hmsl_m1 varchar2(20 char) not null, 
  hmsl_m2 varcahr2(20 char) not null,
  hmsl_last_txt varchar2(300 char) not null, 
  hmsl_last_date date
);

create sequece hitea_messenger_list_seq;






drop table hitea_pagenotice cascade constraint purge;