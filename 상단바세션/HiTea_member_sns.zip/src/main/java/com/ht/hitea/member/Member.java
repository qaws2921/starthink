package com.ht.hitea.member;

public class Member {
	private String hm_id;
	private String hm_pw;
	private String hm_nickname;
	private String hm_name;
	private String hm_birthday;
	private String hm_email;
	private String hm_pw_question;
	private String hm_pw_answer;
	private String hm_selfIntroduction;
	private String hm_photo_front;
	private String hm_photo_back;

	public Member() {
		// TODO Auto-generated constructor stub
	}

	public Member(String hm_id, String hm_pw, String hm_nickname, String hm_name, String hm_birthday, String hm_email,
			String hm_pw_question, String hm_pw_answer, String hm_selfIntroduction, String hm_photo_front,
			String hm_photo_back) {
		super();
		this.hm_id = hm_id;
		this.hm_pw = hm_pw;
		this.hm_nickname = hm_nickname;
		this.hm_name = hm_name;
		this.hm_birthday = hm_birthday;
		this.hm_email = hm_email;
		this.hm_pw_question = hm_pw_question;
		this.hm_pw_answer = hm_pw_answer;
		this.hm_selfIntroduction = hm_selfIntroduction;
		this.hm_photo_front = hm_photo_front;
		this.hm_photo_back = hm_photo_back;
	}

	public String getHm_id() {
		return hm_id;
	}

	public void setHm_id(String hm_id) {
		this.hm_id = hm_id;
	}

	public String getHm_pw() {
		return hm_pw;
	}

	public void setHm_pw(String hm_pw) {
		this.hm_pw = hm_pw;
	}

	public String getHm_nickname() {
		return hm_nickname;
	}

	public void setHm_nickname(String hm_nickname) {
		this.hm_nickname = hm_nickname;
	}

	public String getHm_name() {
		return hm_name;
	}

	public void setHm_name(String hm_name) {
		this.hm_name = hm_name;
	}

	public String getHm_birthday() {
		return hm_birthday;
	}

	public void setHm_birthday(String hm_birthday) {
		this.hm_birthday = hm_birthday;
	}

	public String getHm_email() {
		return hm_email;
	}

	public void setHm_email(String hm_email) {
		this.hm_email = hm_email;
	}

	public String getHm_pw_question() {
		return hm_pw_question;
	}

	public void setHm_pw_question(String hm_pw_question) {
		this.hm_pw_question = hm_pw_question;
	}

	public String getHm_pw_answer() {
		return hm_pw_answer;
	}

	public void setHm_pw_answer(String hm_pw_answer) {
		this.hm_pw_answer = hm_pw_answer;
	}

	public String getHm_selfIntroduction() {
		return hm_selfIntroduction;
	}

	public void setHm_selfIntroduction(String hm_selfIntroduction) {
		this.hm_selfIntroduction = hm_selfIntroduction;
	}

	public String getHm_photo_front() {
		return hm_photo_front;
	}

	public void setHm_photo_front(String hm_photo_front) {
		this.hm_photo_front = hm_photo_front;
	}

	public String getHm_photo_back() {
		return hm_photo_back;
	}

	public void setHm_photo_back(String hm_photo_back) {
		this.hm_photo_back = hm_photo_back;
	}
	
	
}
