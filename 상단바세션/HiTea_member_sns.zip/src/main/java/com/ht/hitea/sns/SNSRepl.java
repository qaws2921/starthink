package com.ht.hitea.sns;

import java.math.BigDecimal;
import java.util.Date;

public class SNSRepl {

	private BigDecimal hsr_no;
	private BigDecimal hsr_hs_no;
	private String hsr_hm_nickname;
	private String hsr_txt;
	private Date hsr_date;

	private String hs_photo_front;

	public SNSRepl() {
		// TODO Auto-generated constructor stub
	}

	public SNSRepl(BigDecimal hsr_no, BigDecimal hsr_hs_no, String hsr_hm_nickname, String hsr_txt, Date hsr_date,
			String hs_photo_front) {
		super();
		this.hsr_no = hsr_no;
		this.hsr_hs_no = hsr_hs_no;
		this.hsr_hm_nickname = hsr_hm_nickname;
		this.hsr_txt = hsr_txt;
		this.hsr_date = hsr_date;
		this.hs_photo_front = hs_photo_front;
	}

	public BigDecimal getHsr_no() {
		return hsr_no;
	}

	public void setHsr_no(BigDecimal hsr_no) {
		this.hsr_no = hsr_no;
	}

	public BigDecimal getHsr_hs_no() {
		return hsr_hs_no;
	}

	public void setHsr_hs_no(BigDecimal hsr_hs_no) {
		this.hsr_hs_no = hsr_hs_no;
	}

	public String getHsr_hm_nickname() {
		return hsr_hm_nickname;
	}

	public void setHsr_hm_nickname(String hsr_hm_nickname) {
		this.hsr_hm_nickname = hsr_hm_nickname;
	}

	public String getHsr_txt() {
		return hsr_txt;
	}

	public void setHsr_txt(String hsr_txt) {
		this.hsr_txt = hsr_txt;
	}

	public Date getHsr_date() {
		return hsr_date;
	}

	public void setHsr_date(Date hsr_date) {
		this.hsr_date = hsr_date;
	}

	public String getHs_photo_front() {
		return hs_photo_front;
	}

	public void setHs_photo_front(String hs_photo_front) {
		this.hs_photo_front = hs_photo_front;
	}

}
