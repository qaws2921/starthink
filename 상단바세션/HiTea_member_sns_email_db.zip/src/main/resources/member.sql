--------------------------------------------------------------------------------
create table hitea_member(
	hm_id varchar2(20 char) primary key,
	hm_pw varchar2(16 char) not null,
	hm_nickname varchar2(8 char) not null,
	hm_name varchar2(10 char) not null,
	hm_email varchar2(100 char) not null,
	hm_pw_question varchar2(30 char) not null,	
	hm_pw_answer varchar2(50 char) not null,	
	hm_selfIntroduction varchar2(100 char) not null,
	hm_photo_front varchar2(100 char) not null,
	hm_photo_back varchar2(100 char) not null
);

-- member 전체 조회
select * from hitea_member;

-- 테이블 삭제
drop table hitea_member cascade constraint purge;

-- 중복 체크
select count(hm_id) from hitea_member where	hm_id= 'qwe';

-- sns닉네임
select hs_hm_nickname from hitea_sns where hs_no = 2;

-- join_yourPage
select hs_hm_nickname, hm_selfIntroduction, hm_photo_front, hm_photo_back 
from hitea_member, hitea_sns
where hm_nickname = hs_hm_nickname
and hm_nickname = 'qwe'
and rownum = 1;

select * from(select rownum as rn, hs_no, hs_hm_nickname, hm_selfIntroduction, hm_photo_front, hm_photo_back from (select * 
from hitea_member, hitea_sns
where hm_nickname = hs_hm_nickname
and hs_hm_nickname = 'iop'
order by hs_no desc))
where rn = 1;

select hm_nickname, hm_photo_front, hm_selfIntroduction 
from hitea_member, hitea_sns
where hm_nickname = hs_hm_nickname
and hs_no = 1;

-- hitea_follow
select * from hitea_follow order by hf_date desc;

-- follower, following 목록
select hf_follower_id, hf_following_hm_id, hm_id, hm_nickname, hm_selfIntroduction, hm_photo_front, hm_photo_back
from hitea_member, hitea_follow
where hm_id = hf_following_hm_id
and hf_follower_id = 'qwe'
order by hf_date desc;

select hf_following_hm_id, hf_follower_id, hm_id, hm_nickname, hm_selfIntroduction, hm_photo_front, hm_photo_back
from hitea_member, hitea_follow
where hm_id = hf_follower_id
and hf_following_hm_id = 'qwe';

-- follower, following 사람 수
select count (hf_follower_id)
from hitea_member, hitea_follow
where hm_id = hf_following_hm_id
and hf_follower_id = 'qwe';

select count (hf_following_hm_id)
from hitea_member, hitea_follow
where hm_id = hf_following_hm_id
and hf_following_hm_id = 'qwe';

-- 내가 만든 모임
select hm_id, hm_nickname, ht_leaderid, ht_profilepic, ht_name, ht_category, ht_no
from hitea_member, hitea_teabag
where hm_id = ht_leaderid
and hm_nickname = 'qwe'
order by ht_no desc;

-- 내가 가입한 모임
select hm_id, hm_nickname, ht_profilepic, ht_name, ht_category
from hitea_teabagmember, hitea_teabag, hitea_member 
where ht_no = htm_tno 
and htm_id != ht_leaderid 
and htm_id = hm_id 
and hm_nickname = '123' 
order by ht_no desc;


--------------------------------------------------------------------------------
-----SNS------------------------------------------------------------------------
create table hitea_sns(
	hs_no number(6) primary key,	
	hs_hm_nickname varchar2(8 char) not null,
	hs_txt varchar2(500 char) not null,	
	hs_txt2 varchar2(500 char) not null,
	hs_txt3 varchar2(500 char) not null,
	hs_photo_front varchar2(200 char) not null,
	hs_date date not null					
); 

-- 테이블 삭제
drop table hitea_sns cascade constraint purge;

create table hitea_sns_repl(
	hsr_no number(6) primary key,		
	hsr_hs_no number(6) not null,		
	hsr_hm_nickname varchar2(8 char) not null,	
	hsr_txt varchar2(200 char) not null,		
	hsr_date date not null,
	constraint hitea_sns_repl_haha foreign key(hsr_hs_no) references hitea_sns(hs_no) on delete cascade
);

-- 테이블 삭제
drop table hitea_sns_repl cascade constraint purge;

create table hitea_files(
	hfile_no number(6) not null,
	hfile_img varchar2(500 char) not null,
	hfile_video varchar2(500 char) not null,
	constraint hitea_files_haha foreign key(hfile_no) references hitea_sns(hs_no) on delete cascade
);

-- 테이블 삭제
drop table hitea_files cascade constraint purge;

create sequence hitea_sns_seq;
create sequence hitea_files_seq;
create sequence hitea_sns_repl_seq;

-- 시퀀스 삭제
drop sequence hitea_sns_seq;
drop sequence hitea_files_seq;
drop sequence hitea_sns_repl_seq;

-- SNS 전체 조회
select * from hitea_sns;
select * from hitea_sns_repl;
select * from hitea_files;

--------------------------------------------------------------------------------
-----etHitea--------------------------------------------------------------------
﻿--팔로우
create table hitea_follow(
	hf_following_hm_id varchar2(20 char) not null,
	hf_follower_id varchar2(20 char) not null,
	hf_date date not null
)

-- qwe
insert into hitea_follow values('asd', 'qwe', sysdate); 
insert into hitea_follow values('zxc', 'qwe', sysdate); 
insert into hitea_follow values('iop', 'qwe', sysdate); 
insert into hitea_follow values('jkl', 'qwe', sysdate); 
insert into hitea_follow values('bnm', 'qwe', sysdate); 
insert into hitea_follow values('qqq', 'qwe', sysdate); 
insert into hitea_follow values('aaa', 'qwe', sysdate); 
insert into hitea_follow values('zzz', 'qwe', sysdate); 
insert into hitea_follow values('www', 'qwe', sysdate);  
insert into hitea_follow values('sss', 'qwe', sysdate); 
insert into hitea_follow values('xxx', 'qwe', sysdate); 
insert into hitea_follow values('ert', 'qwe', sysdate); 
insert into hitea_follow values('dfg', 'qwe', sysdate); 
insert into hitea_follow values('cvb', 'qwe', sysdate); 
insert into hitea_follow values('123', 'qwe', sysdate);

-- asd
insert into hitea_follow values('qwe', 'asd', sysdate);
insert into hitea_follow values('zxc', 'asd', sysdate);
insert into hitea_follow values('iop', 'asd', sysdate);
insert into hitea_follow values('jkl', 'asd', sysdate);
insert into hitea_follow values('bnm', 'asd', sysdate);
insert into hitea_follow values('qqq', 'asd', sysdate);
insert into hitea_follow values('aaa', 'asd', sysdate);
insert into hitea_follow values('zzz', 'asd', sysdate);
insert into hitea_follow values('www', 'asd', sysdate);
insert into hitea_follow values('sss', 'asd', sysdate);
insert into hitea_follow values('xxx', 'asd', sysdate);
insert into hitea_follow values('ert', 'asd', sysdate);
insert into hitea_follow values('dfg', 'asd', sysdate);
insert into hitea_follow values('cvb', 'asd', sysdate);
insert into hitea_follow values('123', 'asd', sysdate);

-- zxc
insert into hitea_follow values('asd', 'zxc', sysdate);
insert into hitea_follow values('qwe', 'zxc', sysdate);
insert into hitea_follow values('iop', 'zxc', sysdate);
insert into hitea_follow values('jkl', 'zxc', sysdate);
insert into hitea_follow values('bnm', 'zxc', sysdate);
insert into hitea_follow values('qqq', 'zxc', sysdate);
insert into hitea_follow values('aaa', 'zxc', sysdate);
insert into hitea_follow values('zzz', 'zxc', sysdate);
insert into hitea_follow values('www', 'zxc', sysdate);
insert into hitea_follow values('sss', 'zxc', sysdate);
insert into hitea_follow values('xxx', 'zxc', sysdate);
insert into hitea_follow values('ert', 'zxc', sysdate);
insert into hitea_follow values('dfg', 'zxc', sysdate);
insert into hitea_follow values('cvb', 'zxc', sysdate);
insert into hitea_follow values('123', 'zxc', sysdate);

-- iop
insert into hitea_follow values('asd', 'iop', sysdate);
insert into hitea_follow values('zxc', 'iop', sysdate);
insert into hitea_follow values('qwe', 'iop', sysdate);
insert into hitea_follow values('jkl', 'iop', sysdate);
insert into hitea_follow values('bnm', 'iop', sysdate);
insert into hitea_follow values('qqq', 'iop', sysdate);
insert into hitea_follow values('aaa', 'iop', sysdate);
insert into hitea_follow values('zzz', 'iop', sysdate);
insert into hitea_follow values('www', 'iop', sysdate);
insert into hitea_follow values('sss', 'iop', sysdate);
insert into hitea_follow values('xxx', 'iop', sysdate);
insert into hitea_follow values('ert', 'iop', sysdate);
insert into hitea_follow values('dfg', 'iop', sysdate);
insert into hitea_follow values('cvb', 'iop', sysdate);
insert into hitea_follow values('123', 'iop', sysdate);

-- jkl
insert into hitea_follow values('asd', 'jkl', sysdate);
insert into hitea_follow values('zxc', 'jkl', sysdate);
insert into hitea_follow values('iop', 'jkl', sysdate);
insert into hitea_follow values('qwe', 'jkl', sysdate);
insert into hitea_follow values('bnm', 'jkl', sysdate);
insert into hitea_follow values('qqq', 'jkl', sysdate);
insert into hitea_follow values('aaa', 'jkl', sysdate);
insert into hitea_follow values('zzz', 'jkl', sysdate);
insert into hitea_follow values('www', 'jkl', sysdate);
insert into hitea_follow values('sss', 'jkl', sysdate);
insert into hitea_follow values('xxx', 'jkl', sysdate);
insert into hitea_follow values('ert', 'jkl', sysdate);
insert into hitea_follow values('dfg', 'jkl', sysdate);
insert into hitea_follow values('cvb', 'jkl', sysdate);
insert into hitea_follow values('123', 'jkl', sysdate);

-- bnm
insert into hitea_follow values('asd', 'bnm', sysdate);
insert into hitea_follow values('zxc', 'bnm', sysdate);
insert into hitea_follow values('iop', 'bnm', sysdate);
insert into hitea_follow values('jkl', 'bnm', sysdate);
insert into hitea_follow values('qwe', 'bnm', sysdate);
insert into hitea_follow values('qqq', 'bnm', sysdate);
insert into hitea_follow values('aaa', 'bnm', sysdate);
insert into hitea_follow values('zzz', 'bnm', sysdate);
insert into hitea_follow values('www', 'bnm', sysdate);
insert into hitea_follow values('sss', 'bnm', sysdate);
insert into hitea_follow values('xxx', 'bnm', sysdate);
insert into hitea_follow values('ert', 'bnm', sysdate);
insert into hitea_follow values('dfg', 'bnm', sysdate);
insert into hitea_follow values('cvb', 'bnm', sysdate);
insert into hitea_follow values('123', 'bnm', sysdate);

-- 123
insert into hitea_follow values('asd', '123', sysdate);
insert into hitea_follow values('zxc', '123', sysdate);
insert into hitea_follow values('iop', '123', sysdate);
insert into hitea_follow values('jkl', '123', sysdate);
insert into hitea_follow values('bnm', '123', sysdate);
insert into hitea_follow values('qqq', '123', sysdate);
insert into hitea_follow values('aaa', '123', sysdate);
insert into hitea_follow values('zzz', '123', sysdate);
insert into hitea_follow values('www', '123', sysdate);
insert into hitea_follow values('sss', '123', sysdate);
insert into hitea_follow values('xxx', '123', sysdate);
insert into hitea_follow values('ert', '123', sysdate);
insert into hitea_follow values('dfg', '123', sysdate);
insert into hitea_follow values('cvb', '123', sysdate);
insert into hitea_follow values('qwe', '123', sysdate);


--좋아요
create table hitea_heart(
	hh_hs_no number(10) not null,
	hh_heart_hm_id varchar2(20 char) not null,
	hh_date date not null,
	constraint sns_heart foreign key(hh_hs_no) references hitea_sns(hs_no) on delete cascade
)

--해시
create table hitea_hash(
	hhash_hs_no number(10) not null,
	hhash_text varchar2(50 char) not null,
	constraint sns_hash foreign key(hhash_hs_no) references hitea_sns(hs_no) on delete cascade
)

--알람
create table hitea_alarm(
	halarm_to_id varchar2(20 char) not null,
	halarm_from_id varchar2(20 char) not null,
	halarm_txt varchar2(20 char) not null,
	halarm_date Date not null
)

--신고
create table hitea_report(
	hr_no number(10) primary key,
	hr_this varchar2(20 char) not null,
	hr_report_id varchar2(20 char) not null,
	hr_text varchar2(300 char) not null,
	hr_catego varchar2(10 char) not null,
	hr_date Date not null
)

create sequence hitea_report_seq

-- etHitea 전체 조회
select * from hitea_follow;
select * from hitea_heart;
select * from hitea_hash;
select * from hitea_alarm;
select * from hitea_report;

--------------------------------------------------------------------------------
-----messenger--------------------------------------------------------------------
﻿--메신저, 채팅 목록
create table hitea_messenger_list(
	hmsl_no number(10) primary key,
	hmsl_m1 varchar2(20 char) not null,
	hosl_m2 varchar2(20 char) not null,
	hmsl_last_txt varchar2(300 char) not null,
	hmsl_last_date date not null
)

create sequence hitea_messenger_list_seq

-- messenger 전체 조회
select * from hitea_messenger_list;

--------------------------------------------------------------------------------
-----teabag---------------------------------------------------------------------
create table hitea_teabag(
	ht_no number(10) primary key,
	ht_name varchar2(15char) not null,
	ht_category varchar2(15char) not null,
	ht_date date not null,
	ht_leaderid varchar2(10char) not null,
	ht_profilepic varchar2(200char) not null,
	ht_bgpic varchar2(200char) not null,
	ht_introduce varchar2(100char) not null,
	ht_minage number(8) not null,
	ht_maxage number(8) not null,
	ht_count number(15) not null
);

-- 테이블 삭제
drop table hitea_teabag cascade constraint purge;

create table hitea_teabagmember(
	htm_id varchar2(10char) not null,
	htm_tno number(10) not null,
	htm_date date not null,
	constraint band_member_terms foreign key (htm_tno) references hitea_teabag(ht_no) on delete cascade
);

create sequence hitea_teabag_seq;

-- 테이블 삭제
drop table hitea_tseabagmember cascade constraint purge;
-- 시퀀스 삭제
drop sequence hitea_teabag_seq;

-- hitea_teabagmember 까지 생성 함 <03/14 12:35 >
-- 나머지는 프로젝트 하면서

-- teabag 전체 조회
select * from hitea_teabag;
select * from hitea_teabagmember;

select * from hitea_teabagmember, hitea_teabag
where htm_tno = ht_no
and ht_leaderid != htm_id
and htm_id = 'asd';


----------------------------------------------------------------------------------------------------
