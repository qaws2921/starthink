function joinSelect() {
	setEmail();
	changeEmail();
	setFindPw();
}

function setEmail() {
	var EAddress = ['이메일 주소를선택', 'gmail.com', 'naver.com', 'nate.com', 'hanmail.net', 'yahoo.co.kr', '직접입력'];
	
	$.each(EAddress,function(i, e) {
		if(($(".memberJoinStepThreeEmailAddress2").val() == "직접입력") && (e == "직접입력")){
			$("#memberJoinStepThreeEmailAddress").append("<option value='"+e+"' selected='selected'>"+EAddress[i]+"</option>");
		}else{
			$("#memberJoinStepThreeEmailAddress").append("<option value='"+e+"'>"+EAddress[i]+"</option>");
		}
	});
}

function changeEmail() {
	if ($("#memberJoinStepThreeEmailAddress").val() == "직접입력") {
		$(".memberJoinStepThreeEmailDirect").attr('type','text');
	}else{
		$(".memberJoinStepThreeEmailDirect").attr('type','hidden');
	}	
}

function setFindPw() {
	var question = ['비밀번호 질문 선택을 선택', '생년월일?', '1~9까지 좋아하는 숫자?', '자주쓰는 핸드폰 뒷자리?', '자신의 보물 제1호는?', '아버지의 성함은?', '어머니의 성함은?', '형제는 몇명?', '처음해본 게임은?', '학창시절 별명은?', '좋아하는 색깔은?'];	

	$.each(question,function(i, e) {
		$(".memberJoinStepThreeHm_pw_question").append("<option value='"+e+"'>"+question[i]+"</option>");
	});
}

