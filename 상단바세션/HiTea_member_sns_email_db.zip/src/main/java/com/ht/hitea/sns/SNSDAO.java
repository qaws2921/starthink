package com.ht.hitea.sns;

import java.io.File;
import java.net.URLDecoder;
import java.util.Enumeration;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ht.hitea.member.Member;
import com.oreilly.servlet.MultipartRequest;
//import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

@Service
public class SNSDAO {

	@Autowired
	private SqlSession ss;
	
	public void fileUpload(SNSBean s, FileUploadBean2 f, HttpServletRequest req) {

		MultipartRequest mr = null;
		String path = req.getSession().getServletContext().getRealPath("/resources/img/sns");

		try {
			mr = new MultipartRequest(req, path, 50 * 1024 * 1024, "utf-8", new DefaultFileRenamePolicy());
		} catch (Exception e) {
			e.printStackTrace();
			return;
		}
		
		
		try {
			Member m = (Member) req.getSession().getAttribute("loginMember");
			s.setHs_hm_nickname(m.getHm_nickname());
			s.setHs_photo_front(m.getHm_photo_front());
						
			String s_txt = mr.getParameter("hs_txt");
			String s_txt2 = mr.getParameter("hs_txt2");
			String s_txt3 = mr.getParameter("hs_txt3");
			
			if (!s_txt.equals("")) {
			} else {
				s_txt = "X";
			}		
			
			if (!s_txt2.equals("")) {
			} else {
				s_txt2 = "X";
			}	
			
			if (!s_txt3.equals("")) {
			} else {
				s_txt3 = "X";
			}	
			
//			System.out.println(m.getHm_nickname());
//			System.out.println(s_txt);
//			System.out.println(s_txt2);
//			System.out.println(s_txt3);
//			System.out.println(m.getHm_photo_front());
			
			s.setHs_txt(s_txt);
			s.setHs_txt2(s_txt2);
			s.setHs_txt3(s_txt3);
			
			ss.getMapper(FileUploadMapper.class).snsWrite2(s);
						
			Enumeration forms =  mr.getFileNames();
			
			String formName = null;
			
			String f_img = null;
			String f_video = null;
			
	
			while (forms.hasMoreElements()){
				formName = (String) forms.nextElement();
				
//				System.out.println(formName);
				
				String ext = formName.substring(formName.lastIndexOf(".") + 1, formName.length());
					
				if (ext.equals("png") || ext.equals("jpg") || ext.equals("gif") || ext.equals("bmp") || ext.equals("jpeg")) {
					f_img = mr.getFilesystemName(formName);
					f_video = "no";
				}
				else if (ext.equals("avi") || ext.equals("wmv") || ext.equals("mpeg") || ext.equals("mpg") || ext.equals("asf") || ext.equals("mp4") || ext.equals("mov")) {
					f_video = mr.getFilesystemName(formName);
					f_img = "no";
				}
									
				else {
					f_img = "X";
					f_video = "X";
				}
				
				f.setHfile_img(f_img);
				f.setHfile_video(f_video);
				
				SNSBean s2 = ss.getMapper(FileUploadMapper.class).getOne2();
				
				f.setHfile_no(s2.getHs_no());
				
				ss.getMapper(FileUploadMapper.class).fileWrite2(f);
				
				}
		} catch (Exception e) {
			req.setAttribute("result", "글쓰기 실패");
			e.printStackTrace();
			File file = new File(path + "/" + mr.getFilesystemName("m_photo"));
			file.delete();
		}
		
	}
	
	

	public void getAllSNS(HttpServletRequest req){
		
		List<SNSBean> allmsg = ss.getMapper(FileUploadMapper.class).getAllSNSMsg2();
		for (SNSBean sb2 : allmsg) {
			sb2.setS_files(ss.getMapper(FileUploadMapper.class).getAllfile2(sb2));
			sb2.setS_repls(ss.getMapper(SNSReplMapper.class).getAllRepl(sb2));
		
		}
		req.setAttribute("msgs", allmsg);
	}
	
	
	public SNSBeans getJsonNo(SNSBean s, HttpServletRequest req, HttpServletResponse res){
		
		SNSBean s2 = ss.getMapper(FileUploadMapper.class).getSNSMsg(s);
		s2.setS_files(ss.getMapper(FileUploadMapper.class).getAllfile2(s));
		s2.setS_repls(ss.getMapper(SNSReplMapper.class).getAllRepl(s));
		
		return new SNSBeans(s2);
	}
	
	
	public void snsDelete(SNSBean s, HttpServletRequest req){
		
		List<FileUploadBean2> f = ss.getMapper(FileUploadMapper.class).getAllfile2(s);

		try {
			if (ss.getMapper(FileUploadMapper.class).snsDelete(s) == 1) {
				
				for (FileUploadBean2 fb2 : f) {
					
					String f_img = fb2.getHfile_img();
					f_img = URLDecoder.decode(f_img, "utf-8");
					String path = req.getSession().getServletContext().getRealPath("resources/img/sns");
					
					File file = new File(path + "/" + f_img);
					file.delete();
					
					String f_video = fb2.getHfile_video();
					f_video = URLDecoder.decode(f_video, "utf-8");
					
					File file2 = new File(path + "/" + f_video);
					file2.delete();
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public void snsReWrite(SNSRepl sr, HttpServletRequest req){
		try {
			Member m = (Member) req.getSession().getAttribute("loginMember");
			sr.setHsr_hm_nickname(m.getHm_nickname());
			sr.setHs_photo_front(m.getHm_photo_front());
			ss.getMapper(SNSReplMapper.class).snsReWrite(sr);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	

	public void snsReDelete(SNSRepl sr, HttpServletRequest req){
		try {
			ss.getMapper(SNSReplMapper.class).snsReDelete(sr);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	

}
