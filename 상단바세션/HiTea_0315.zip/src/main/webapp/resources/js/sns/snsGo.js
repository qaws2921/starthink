function goSNSReDel(hsr_no) {
	if (confirm("진짜 삭제?")) {
		location.href = "snsRedelete.go?hsr_no=" + hsr_no;
	}
}



function goSNSDel() {
    $(".snsButton2").click(function() {
   		var hs_no = $(this).parent().parent().parent().find(".hs_no").val();
   		if (confirm("진짜 삭제??")) {
   			location.href = "sns.delete.go?hs_no=" + encodeURI(hs_no);
   		}
    });
}


function goYourPage() {
	location.href = "yourPageGo";
}