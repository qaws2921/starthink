function goMessenger() {
	location.href = "messenger";
}

