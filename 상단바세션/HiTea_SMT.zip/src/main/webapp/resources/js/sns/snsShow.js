function scrollShow() {
	
	
	var pNo = 1;
	snsAllShow(pNo);
	
	

	
	$(window).scroll(function() {
		var htmlHeight = $(document).height();
		var scrollBottom =$(window).scrollTop() + $(window).height();
		
		if (scrollBottom+1 >= htmlHeight) {
			pNo++;
			snsAllShow(pNo);
			
			
		}
	});
}
var login_sm_id;
function snsAllShow(pNo) {
	
	$.getJSON("sns.page.ajax?page="+pNo,function(data){
		login_sm_id = $("#login_sm_id").val();
		$.each(data.snsBeans,function(i1,s){
		
			var snsMsgTable = $("<table></table>").attr("class","snsMsgTable");
			
			var snsMemberImg = $("<img>").attr("src","resources/img/member/"+s.hs_photo_front).attr("style","width: 50px;");
			var snsMemberNickname = $("<span></span>").text(s.hs_hm_nickname).attr("class","snsHs_hm_nicknameSpan");
			var snsMemberInput = $("<input>").attr("class","snsHm_nicknameInput").attr("value",$("#hm_nickname").val()).attr("type","hidden");
			var snsMember = $("<td></td>").attr("align","left").attr("class","snsMember").append(snsMemberImg,snsMemberNickname,snsMemberInput);
			
			var snsDelete = $("<td></td>").attr("align","right");
			if (login_sm_id == s.hs_hm_id) {
				var snsButtonImg = $("<img>").attr("src","resources/img/sns/snsdeleteicon.png").attr("style","width: 30px;").attr("onclick","goSNSDel("+s.hs_no+")");
				var snsButton2 = $("<span></span>").attr("class","snsButton2").append(snsButtonImg);
			}else {
				var snsButton2 = $("<span></span>");
			}
			snsDelete.append(snsButton2);
			
			var snsMemberTr = $("<tr></tr>").append(snsMember,snsDelete);
			///////////////////////////////////////////////////
			
			var snsTxt = $("<textarea></textarea>").attr("class","snsTxt").attr("name","hs_txt").attr("readonly","readonly").text(s.hs_txt);
			var snsTxtTd = $("<td></td>").attr("class","snsTxtTd").attr("align","center").attr("colspan","2").append(snsTxt);
			
			var snsTxtTdTr = $("<tr></tr>").append(snsTxtTd);
			
			/////////////////////////////////////////////////
			var snsTxt2Td = $("<td></td>").attr("class","snsTxt2Td").attr("align","center").attr("colspan","2");
			for (var x = 0; x < s.s_hashs.length; x++) {
				var fHash = s.s_hashs[x].hhash_text;
				if (fHash.charAt(0)=="#") {
					var hameSNSHashA = $("<a></a>").attr("href", "seach.go?etseach="+s.s_hashs[x].hhash_text.substring(1)).append(s.s_hashs[x].hhash_text);
					var homeSNSHash = $("<span></span>").attr("class","homeHash").text(" ").append(hameSNSHashA);
					snsTxt2Td.append(homeSNSHash);		
				}
			}
			
			var snsTxt2TdTr = $("<tr></tr>").append(snsTxt2Td);
			
			///////////////////////////////////////////////
			
			var snsTxt3Td = $("<td></td>").attr("class","snsTxt3Td").attr("align","center").attr("colspan","2");

			for (var x = 0; x < s.s_hashs.length; x++) {
				var fHash = s.s_hashs[x].hhash_text;
				if (fHash.charAt(0)=="!") {
					var hameSNSHashA = $("<a></a>").attr("onclick", "teabagHashGo('"+s.s_hashs[x].hhash_text.substring(1)+"')").append(s.s_hashs[x].hhash_text);
					var homeSNSHash = $("<span></span>").attr("class","homeHash").text(" ").append(hameSNSHashA);
					snsTxt3Td.append(homeSNSHash);		
				}
			}
			
			var snsTxt3TdTr = $("<tr></tr>").append(snsTxt3Td);
			
			//////////////////////////////////////////////////////////
			var snsDateTd = $("<td></td>").attr("align","right").attr("style","color: #FAC03B;").attr("colspan","2");
			
			var snsDateYear = s.hs_date.year;
			var snsDatemonthValue = s.hs_date.monthValue;
			if (s.hs_date.monthValue < 10) {
				snsDatemonthValue = "0"+s.hs_date.monthValue;
			}
			var snsDatedayOfMonth = s.hs_date.dayOfMonth;
			if (s.hs_date.dayOfMonth < 10) {
				snsDatedayOfMonth = "0"+s.hs_date.dayOfMonth;
			}
			var snsDatehour = s.hs_date.hour;
			if (s.hs_date.hour < 10) {
				s.hs_date.hour = "0"+s.hs_date.hour;
			}
			var snsDateminute = s.hs_date.minute;
			if (s.hs_date.minute < 10) {
				s.hs_date.minute = "0"+s.hs_date.minute;
			}
			var dateAll = snsDateYear+"/"+snsDatemonthValue+"/"+snsDatedayOfMonth+"/"+snsDatehour+":"+snsDateminute;
			
			snsDateTd.text(dateAll);
			
			
			var snsDateTr = $("<tr></tr>").append(snsDateTd);
			///////////////////////////////////////////
			
			var snsFileTr = $("<tr></tr>");
			var snsFileTd = $("<td></td>").attr("align","center").attr("style","width: 490px;").attr("colspan","2");
//			var bxwrapper = $("<div></div>").attr("class","bx-wrapper").attr("style","max-width: 485px;");
//			var bxviewport =$("<div></div>").attr("class","bx-viewport").attr("aria-live","polite").attr("style","width: 100%; overflow: hidden; position: relative; height: 200px;");
			
			
			if (s.s_files.length != 0) {
				var snsbxslider = $("<div></div>").attr("class","snsbxslider").attr("align","center").attr("style","width: 100%;");
				for (var y = 0; y <s.s_files.length; y++) {
					if (s.s_files[y].hfile_img == 'X' || s.s_files[y].hfile_video == 'X') {
						var snsfileImg = $("<img>").attr("style","max-width: 80%; min-width:50%; height: 80%;").attr("src","resources/img/sns/file.png");
						var snsb = $("<div></div>").attr("class","snsb").append(snsfileImg);
					}else {
						if (s.s_files[y].hfile_img == 'no') {
							var snsfileVideo = $("<video></video>").attr("style","max-width: 80%; min-width:50%; height: 100%;").attr("src","resources/img/sns/"+s.s_files[y].hfile_video).attr("controls","controls");
							var snsb = $("<div></div>").attr("class","snsb").append(snsfileVideo);
						}else {
							var snsfileImg = $("<img>").attr("style","max-width: 80%; min-width:50%; height: 100%;").attr("src","resources/img/sns/"+s.s_files[y].hfile_img);
							var snsb = $("<div></div>").attr("class","snsb").append(snsfileImg);
//						var snsb = $("<div></div>").attr("aria-hidden","false").attr("style","width: float: none; list-style: none; position: absolute; width: 485px; z-index: 50; display: block;").attr("class","snsb").append(snsfileImg);
							
						}
					}
					snsbxslider.append(snsb);
				}
				snsFileTd.append(snsbxslider);
			}else {
				var snsbxslider = $("<div></div>").attr("align","center").attr("style","width: 100%;");
				snsFileTd.append(snsbxslider);
			}
//			bxviewport.append(snsbxslider);
//			bxwrapper.append(bxviewport);
			snsFileTr.append(snsFileTd);
			/////////////////////////////////////////////////
			var heartCheck = "heart.png";
			
			if ( s.s_harts != null) {
				for (var i = 0; i < s.s_harts.length; i++) {
					if (s.s_harts[i].hh_heart_hm_id ==  login_sm_id) {
						heartCheck = "heartOk.png";
					}
				}
				
			}
			var snsHeartNoInput = $("<input>").attr("class","snsHeartNoInput").attr("type","hidden").attr("value",s.hs_no);
			var snsHeartIdInput = $("<input>").attr("class","snsHeartIdInput").attr("type","hidden").attr("value",s.hs_hm_id);

			var snsHeartImg = $("<img>").attr("class","heartImg").attr("src","resources/img/sns/"+heartCheck);;
			var snsHeartLength = $("<span></span>").attr("class","heartCount").text("("+s.s_harts.length+")");
			var snsReportImg = $("<img>").attr("class","reportImg").attr("src","resources/img/sns/plus.png").attr("onclick","reportClick('"+s.hs_no+"','"+login_sm_id+"','"+"글"+"')");
			var snsReportS =  $("<span></span>").html("&nbsp;").append(snsReportImg);
			
			var snsHRTd = $("<td></td>").attr("colspan","2").append(snsHeartNoInput,snsHeartIdInput,snsHeartImg,snsHeartLength,snsReportS);
			var snsHRTr = $("<tr></tr>").append(snsHRTd);
			
			///////////////////////////////////////////////
			
			var hsr_hs_no = $("<input>").attr("value",s.hs_no).attr("name","hsr_hs_no").attr("type","hidden");
			var snsReInput = $("<input>").attr("class","snsReInput").attr("name","hsr_txt").attr("placeholder","댓글작성, 30자 이내로 쓰세요");
			var snsReButton = $("<button></button>").attr("class","snsReButton").text("쓰기");
			var snsReForm = $("<form></form>").attr("action","snsRewrite.go").attr("name","snsReForm").attr("onsubmit","return snsReWriteCheck(this);").append(hsr_hs_no,snsReInput,snsReButton);
			var snsReInputTd = $("<td></td>").attr("class","snsReInputTd").attr("style","width: 50%;").attr("align","center").attr("colspan","2").append(snsReForm);
			var snsReTr = $("<tr></tr>").append(snsReInputTd);
			//////////////////////////////////////////////
			
			var snsResTr = $("<tr></tr>");
			var snsReTable = $("<td></td>").attr("class","snsReTable").attr("style","font-size: 12pt;").attr("colspan","2");
			for (var z = 0; z < s.s_repls.length; z++) {
				var snsreImg = $("<img>").attr("src","resources/img/member/"+s.s_repls[z].hsr_img).attr("style","width: 30px;");
				var snsrenickname = $("<span></span>").html(s.s_repls[z].hsr_hm_nickname).html("&nbsp;");
				var snssm1 = $("<span></span>").attr("class","snssm1").attr("onclick","goYourPage();").append(snsreImg,snsrenickname);
				
				var snssm2 = $("<span></span>").text(s.s_repls[z].hsr_txt);
				
				var snsDateYearre = s.s_repls[z].hsr_date.year;
				var snsDatemonthValuere = s.s_repls[z].hsr_date.monthValue;
				if (s.s_repls[z].hsr_date.monthValue < 10) {
					snsDatemonthValuere = "0"+s.s_repls[z].hsr_date.monthValue;
				}
				var snsDatedayOfMonthre = s.s_repls[z].hsr_date.dayOfMonth;
				if (s.s_repls[z].hsr_date.dayOfMonth < 10) {
					snsDatedayOfMonthre = "0"+s.s_repls[z].hsr_date.dayOfMonth;
				}
				var snsDatehourre = s.s_repls[z].hsr_date.hour;
				if (s.s_repls[z].hsr_date.hour < 10) {
					snsDatehourre  = "0"+s.s_repls[z].hsr_date.hour;
				}
				var snsDateminutere = s.s_repls[z].hsr_date.minute;
				if (s.s_repls[z].hsr_date.minute < 10) {
					snsDateminutere = "0"+s.s_repls[z].hsr_date.minute;
				}
				var dateAllre = snsDateYearre+"/"+snsDatemonthValuere+"/"+snsDatedayOfMonthre+"/"+snsDatehourre+":"+snsDateminutere;
				
	
				var snssm3 = $("<span></span>").html(dateAllre+"&nbsp;").attr("style","color: #FAC03B; font-size: 6pt;");
				
				if (login_sm_id == s.hs_hm_id) {
					var snsredelete = $("<img>").attr("src","resources/img/sns/snsdelete.png").attr("onclick","goSNSReDel("+s.s_repls[z].hsr_no+")").attr("style","width: 15px;");
					var snssm4 = $("<span></span>").append(snsredelete);
					
				}else {
					var snssm4 = $("<span></span>");	
				}
				var snsrebr = $("<br>");
				snsReTable.append(snssm1,snssm2,snssm3,snssm4,snsrebr);
				
			}
			snsResTr.append(snsReTable);
			//////////////////////////////////////
			var snsNoInput = $("<input>").attr("class","snsNoInput").attr("type","hidden").attr("value",s.hs_no);
			var snsRessA = $("<span></span>").attr("class","snsRessA").text("이전 댓글 더보기");
			var snsRessTd = $("<td></td>").attr("colspan","2").append(snsNoInput,snsRessA);
			var snsRessTr = $("<tr></tr>").append(snsRessTd);
			
			

			snsMsgTable.append(snsMemberTr,snsTxtTdTr,snsTxt2TdTr,snsTxt3TdTr,snsDateTr,snsFileTr,snsHRTr,snsReTr,snsResTr,snsRessTr);
			$("#snsMsgTableTd").append(snsMsgTable);
			///////////////////////////////////
			$('.snsbxslider').bxSlider({
				slideWidth : 485,
				adaptiveHeight : false,
				slideMargin : 0,
				mode : 'fade',
				caption : false
				});
			//////////////////////////////////////
		});	
		
		
		
		
	});
}

function snsReAll() {
	var login_sm_nickname = $("#login_sm_nickname").val();
	$(document).on("click",".snsRessA",function(){
		var hs_no = $(this).parent().find(".snsNoInput").val();
		var snsReTable = $(this).parent().parent().parent().find(".snsReTable");
		$(this).removeClass('snsRessA').text("댓글 3개 보기").attr("class","snsRessB");
		snsReTable.empty();
		$.getJSON("sns.Repl.ajax?hs_no="+hs_no,function(data){
			
			
			for (var z = 0; z < data.snsRepl.length; z++) {
				
				var snsreImg = $("<img>").attr("src","resources/img/member/"+data.snsRepl[z].hsr_img).attr("style","width: 30px;");
				var snsrenickname = $("<span></span>").html(data.snsRepl[z].hsr_hm_nickname).html("&nbsp;");
				var snssm1 = $("<span></span>").attr("class","snssm1").attr("onclick","goYourPage();").append(snsreImg,snsrenickname);
				
				var snssm2 = $("<span></span>").text(data.snsRepl[z].hsr_txt);
				
				var snsDateYearre = data.snsRepl[z].hsr_date.year;
				var snsDatemonthValuere = data.snsRepl[z].hsr_date.monthValue;
				if (data.snsRepl[z].hsr_date.monthValue < 10) {
					snsDatemonthValuere = "0"+data.snsRepl[z].hsr_date.monthValue;
				}
				var snsDatedayOfMonthre = data.snsRepl[z].hsr_date.dayOfMonth;
				if (data.snsRepl[z].hsr_date.dayOfMonth < 10) {
					snsDatedayOfMonthre = "0"+data.snsRepl[z].hsr_date.dayOfMonth;
				}
				var snsDatehourre = data.snsRepl[z].hsr_date.hour;
				if (data.snsRepl[z].hsr_date.hour < 10) {
					snsDatehourre  = "0"+data.snsRepl[z].hsr_date.hour;
				}
				var snsDateminutere = data.snsRepl[z].hsr_date.minute;
				if (data.snsRepl[z].hsr_date.minute < 10) {
					snsDateminutere = "0"+data.snsRepl[z].hsr_date.minute;
				}
				var dateAllre = snsDateYearre+"/"+snsDatemonthValuere+"/"+snsDatedayOfMonthre+"/"+snsDatehourre+":"+snsDateminutere;
				
				var snssm3 = $("<span></span>").html(dateAllre+"&nbsp;").attr("style","color: #FAC03B; font-size: 6pt;");
				
				if (login_sm_nickname == data.snsRepl[z].hsr_hm_nickname) {
					var snsredelete = $("<img>").attr("src","resources/img/sns/snsdelete.png").attr("onclick","goSNSReDel("+data.snsRepl[z].hsr_no+")").attr("style","width: 15px;");
					var snssm4 = $("<span></span>").append(snsredelete);
					
				}else {
					var snssm4 = $("<span></span>");	
				}
				var snsrebr = $("<br>");
				snsReTable.append(snssm1,snssm2,snssm3,snssm4,snsrebr);
				
			}
		});
	});
}

function snsReAll3(){
	var login_sm_nickname = $("#login_sm_nickname").val();
	$(document).on("click",".snsRessB",function(){
		var hs_no = $(this).parent().find(".snsNoInput").val();
		var snsReTable = $(this).parent().parent().parent().find(".snsReTable");
		$(this).removeClass('snsRessB').text("이전 댓글 보기").attr("class","snsRessA");
		snsReTable.empty();
		$.getJSON("sns.Repl3.ajax?hs_no="+hs_no,function(data){
			
			
			for (var z = 0; z < data.snsRepl.length; z++) {
				
				var snsreImg = $("<img>").attr("src","resources/img/member/"+data.snsRepl[z].hsr_img).attr("style","width: 30px;");
				var snsrenickname = $("<span></span>").html(data.snsRepl[z].hsr_hm_nickname).html("&nbsp;");
				var snssm1 = $("<span></span>").attr("class","snssm1").attr("onclick","goYourPage();").append(snsreImg,snsrenickname);
				
				var snssm2 = $("<span></span>").text(data.snsRepl[z].hsr_txt);
				
				var snsDateYearre = data.snsRepl[z].hsr_date.year;
				var snsDatemonthValuere = data.snsRepl[z].hsr_date.monthValue;
				if (data.snsRepl[z].hsr_date.monthValue < 10) {
					snsDatemonthValuere = "0"+data.snsRepl[z].hsr_date.monthValue;
				}
				var snsDatedayOfMonthre = data.snsRepl[z].hsr_date.dayOfMonth;
				if (data.snsRepl[z].hsr_date.dayOfMonth < 10) {
					snsDatedayOfMonthre = "0"+data.snsRepl[z].hsr_date.dayOfMonth;
				}
				var snsDatehourre = data.snsRepl[z].hsr_date.hour;
				if (data.snsRepl[z].hsr_date.hour < 10) {
					snsDatehourre  = "0"+data.snsRepl[z].hsr_date.hour;
				}
				var snsDateminutere = data.snsRepl[z].hsr_date.minute;
				if (data.snsRepl[z].hsr_date.minute < 10) {
					snsDateminutere = "0"+data.snsRepl[z].hsr_date.minute;
				}
				var dateAllre = snsDateYearre+"/"+snsDatemonthValuere+"/"+snsDatedayOfMonthre+"/"+snsDatehourre+":"+snsDateminutere;
				
				var snssm3 = $("<span></span>").html(dateAllre+"&nbsp;").attr("style","color: #FAC03B; font-size: 6pt;");
				
				if (login_sm_nickname == data.snsRepl[z].hsr_hm_nickname) {
					var snsredelete = $("<img>").attr("src","resources/img/sns/snsdelete.png").attr("onclick","goSNSReDel("+data.snsRepl[z].hsr_no+")").attr("style","width: 15px;");
					var snssm4 = $("<span></span>").append(snsredelete);
					
				}else {
					var snssm4 = $("<span></span>");	
				}
				var snsrebr = $("<br>");
				snsReTable.append(snssm1,snssm2,snssm3,snssm4,snsrebr);
				
			}
		});
	});
}


function hashSharp() {
	$(document).on("click",".hs_txt2",function(){
		$(".hs_txt2").val("#");
	});
	$(document).on("click",".hs_txt3",function(){
		$(".hs_txt3").val("!");
	});
	
	$(".hs_txt2").keyup(function(e) {
		if (e.keyCode == "32") {
			var what = $(".hs_txt2").val();
			var what2 = what+"#";
			var arr = what2.split(" ");
			arr = removeDuplicatesArray(arr);
			var s = arr.join(' ');
			$(".hs_txt2").val(s);
		}
		
		if (e.keyCode == "8") {
			if ($(".hs_txt2").val() == "") {
				$(".hs_txt2").val("#");
			}
		}
	});
	$(".hs_txt3").keyup(function(e) {
		if (e.keyCode == "32") {
			var what = $(".hs_txt3").val();
			var what2 = what+"!";
			var arr = what2.split(" ");
			arr = removeDuplicatesArray(arr);
			var s = arr.join(' ');
			$(".hs_txt3").val(s);
		}
		
		if (e.keyCode == "8") {
			if ($(".hs_txt3").val() == "") {
				$(".hs_txt3").val("!");
			}
		}
	});
	
	
}

function removeDuplicatesArray(arr) {
    var tempArr = [];
    for (var i = 0; i < arr.length; i++) {
        if (tempArr.length == 0) {
            tempArr.push(arr[i]);
        } else {
            var duplicatesFlag = true;
            for (var j = 0; j < tempArr.length; j++) {
                if (tempArr[j] == arr[i]) {
                    duplicatesFlag = false;
                    break;
                }
            }
            if (duplicatesFlag) {
                tempArr.push(arr[i]);
            }
        }
    }
    return tempArr;
}

function hartImgClic() {
	$(document).on("click",".heartImg",function(){
		var heartImg = $(this);
		var heartCount = $(this).parent().find(".heartCount");
		var st_no2 = $(this).parent().find(".snsHeartNoInput").val();
		var st_id = $(this).parent().find(".snsHeartIdInput").val();
		var le = 0;
		$.getJSON("hart.check.img?hs_no="+st_no2+"&hs_hm_id="+login_sm_id,function(data) {
			$.getJSON("hart.check?hs_no="+st_no2,function(data3) {
				le = data.hart.length;
				if (le >= 1) {	
					$.getJSON("hart.delete?hs_no="+st_no2+"&hs_hm_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length-1;
						heartImg.attr("class","heartImg").attr("src","resources/img/sns/heart.png");
						heartCount.empty();
						heartCount.text("("+num+")");
					});
				}else {
					$.getJSON("hart.reg?hs_no="+st_no2+"&hs_hm_id="+login_sm_id+"&hs_hm_id2="+login_sm_id+"&st_id="+st_id,function(data2) {
						
						var num = data3.hart.length+1;
						heartImg.attr("class","heartImg").attr("src","resources/img/sns/heartOk.png");
						heartCount.empty();
						heartCount.text("("+num+")");
					});
				}
			});
		});
	}); 
}

function teabagHashGo(ht_name) {
	$.getJSON("site.teabag.getTeabagByName?ht_name="+ht_name,function(data){
		if (data.teabag.length == 1) {
			location.href="site.teabag.go?ht_no="+data.teabag[0].ht_no;
		}else {
			alert("없는 teabag입니다.");
		}
	});
}

