package com.ht.hitea.sns;

import java.util.List;

public interface FileUploadMapper {
	
	public abstract int snsWrite2(SNSBean s);
	
	public abstract List<SNSBean> getAllSNSMsg2(); 

	public abstract int fileWrite2(FileUploadBean2 f);
	
	public abstract SNSBean getOne2();

	public abstract List<FileUploadBean2> getAllfile2(SNSBean s);
	
	public abstract SNSBean getSNSMsg(SNSBean s);
	
	public abstract int snsDelete(SNSBean s);

		
}
