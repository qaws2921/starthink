package com.ht.hitea;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.ht.hitea.member.Member;
import com.ht.hitea.member.MemberDAO;
import com.ht.hitea.sns.SNSDAO;

@Controller
public class HomeController {

	@Autowired
	private MemberDAO mDAO;
	
	@Autowired
	private SNSDAO sDAO;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String home(HttpServletRequest req, HttpServletResponse res) {		
		if (mDAO.loginCheck(req, res)) {
			sDAO.getAllSNS(req);
			req.setAttribute("contentPage", "sns/sns.jsp");
			return "index";
		} else {
			req.setAttribute("loginPage", "member/login.jsp");
			return "home";
		}
	}
	
	@RequestMapping(value = "/jc", method = RequestMethod.GET)
	public String homeGo(HttpServletRequest req, HttpServletResponse res) {
		req.setAttribute("loginPage", "member/login.jsp");
		return "home";
	}
	
	@RequestMapping(value = "/goLogo", method = RequestMethod.GET)
	public String login(Member m, HttpServletRequest req, HttpServletResponse res) {
		if (mDAO.loginCheck(req, res)) {
//			Member loginMember = (Member) req.getSession().getAttribute("loginMember");
//			System.out.println(loginMember.getHm_photo_front());
			sDAO.getAllSNS(req);
			req.setAttribute("contentPage", "sns/sns.jsp");
			return "index";
		} else {
			return "home";
		}
	}
	
}
