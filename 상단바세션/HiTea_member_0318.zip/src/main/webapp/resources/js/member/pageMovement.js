function goHome() {
	location.href = "jc";	
}

function goJoinOne() {
	location.href = "joinStepOneGo";	
}

function goJoinTwo() {
	location.href = "joinStepTwoGo";	
}

function goSearch() {
	location.href = "idpwSearchGo";	
}

function goMyPage() {
	location.href = "myPageGo";	
}

function goMyPageUpdatePwCheck() {
	location.href = "myPageUpdatePwCheckGo";
}

function goMyPageDeleteGo() {
	location.href = "memberDeleteGo";
}

function goMyPageWritin() {
	location.href = "myPageWritingGo";	
}

function goMyPageMoim() {
	location.href = "myPageMoimGo";	
}

function goMyPageGood() {
	location.href = "myPageGoodGo";	
}

function goMyPageFollow() {
	location.href = "myPageFollowGo";	
}

function goMyPageFollowing() {
	location.href = "myPageFollowingGo";	
}


function goYourPage() {
	location.href = "yourPageGo";		
} 

function goYourPageWriting() {
	location.href = "yourPageWritingGo";	
}

function goYourPageMoim() {
	location.href = "yourPageMoimGo";	
}

function goYourPageGood() {
	location.href = "yourPageGoodGo";	
}

function goYourPageFollow() {
	location.href = "yourPageFollowGo";	
}

function goYourPageFollowing() {
	location.href = "yourPageFollowingGo";	
}



