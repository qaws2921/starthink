package com.ht.hitea.member;

import java.text.SimpleDateFormat;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class MemberDAO {
	
	@Autowired
	private SqlSession ss;
	
	
	public boolean loginCheck(HttpServletRequest req, HttpServletResponse res) {
		autologin(req, res);
		Member m = (Member) req.getSession().getAttribute("loginMember");
		if (m != null) {
			return true;
		} else {
			req.setAttribute("loginPage", "member/login.jsp");
			return false;
		}
	}
	
	public void joinInformation(Member m, HttpServletRequest req) {
		req.setAttribute("member", m);
	}

	public int idCheckJson(Member m) {
		return new Integer(ss.getMapper(MemberMapper.class).idCheckJson(m));
	}

	public int nicknameCheckJson(Member m) {
		return new Integer(ss.getMapper(MemberMapper.class).nicknameCheckJson(m));
	}

	public int emailCheckJson(Member m) {
		return new Integer(ss.getMapper(MemberMapper.class).emailCheckJson(m));
	}
	
	public boolean dateYN(Member m, HttpServletRequest req, HttpServletResponse res) {
		String by = req.getParameter("birthdayY");
		String bm = req.getParameter("birthdayM");
		String bd = req.getParameter("birthdayD");
		String emailId = req.getParameter("emailId");
		String emailAddress = req.getParameter("emailAddress");
		String emailDirect = req.getParameter("emailDirect");

		String tm_birthday = by + "년" + bm + "월" + bd + "일";
		m.setHm_birthday(tm_birthday);

		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy년MM월dd일");
			sdf.setLenient(false);
			sdf.parse(tm_birthday);
		} catch (Exception e) {
			e.printStackTrace();
			req.setAttribute("date", "존재하는 않는 날짜 입니다");
			req.setAttribute("emailId", emailId);
			req.setAttribute("emailAddress2", emailAddress);
			req.setAttribute("type", "1");

			if (emailAddress.equals("직접입력")) {
				req.setAttribute("emailDirect", emailDirect);
			}

			return false;
		}
		return true;
	}
	
	public void join(Member m, HttpServletRequest req, HttpServletResponse res) {

		try {
			String hm_id = m.getHm_id();
			m.setHm_id(hm_id);

			String hm_pw = m.getHm_pw();
			m.setHm_pw(hm_pw);

			String hm_nickname = m.getHm_nickname();
			m.setHm_nickname(hm_nickname);

			String hm_name = req.getParameter("hm_name");
			m.setHm_name(hm_name);

			String by = req.getParameter("birthdayY");
			String bm = req.getParameter("birthdayM");
			String bd = req.getParameter("birthdayD");
			String hm_birthday = by + "년" + bm + "월" + bd + "일";
			m.setHm_birthday(hm_birthday);

			String emailId = req.getParameter("emailId");
			String emailAddress = req.getParameter("emailAddress");
			String emailDirect = req.getParameter("emailDirect");
			String hm_email = null;

			if (emailAddress.equals("직접입력")) {
				emailAddress = emailDirect;
				hm_email = emailId + "@" + emailDirect;
				m.setHm_email(hm_email);
			} else {
				hm_email = emailId + "@" + emailAddress;
				m.setHm_email(hm_email);
			}

			String hm_pw_question = req.getParameter("hm_pw_question");
			m.setHm_pw_question(hm_pw_question);

			String hm_pw_answer = req.getParameter("hm_pw_answer");
			m.setHm_pw_answer(hm_pw_answer);

			String hm_seifIntroduction = "안녕하세요";
			m.setHm_selfIntroduction(hm_seifIntroduction);

			String hm_photo_front = "photo_front.png";
			m.setHm_photo_front(hm_photo_front);
			String hm_photo_back = "photo_back.png";
			m.setHm_photo_back(hm_photo_back);


			if (ss.getMapper(MemberMapper.class).join(m) == 1) {
				req.setAttribute("result", "가입 성공");
				Cookie joinId = new Cookie("joinId", m.getHm_id());
				joinId.setMaxAge(30);
				res.addCookie(joinId);
			}

		} catch (Exception e) {
			req.setAttribute("result", "가입 실패");
			e.printStackTrace();
		}
	}
	
	public void login(Member m, HttpServletRequest req, HttpServletResponse res) {
		try {
			Member dbM = ss.getMapper(MemberMapper.class).getMemberByID(m);
			if (dbM != null) {
				if (m.getHm_pw().equals(dbM.getHm_pw())) {
					req.getSession().setAttribute("loginMember", dbM);
					req.getSession().setMaxInactiveInterval(15 * 60 * 60);
					
					String hm_auto = req.getParameter("hm_auto");
					
					if (hm_auto != null) {

						Cookie autoLoginID = new Cookie("autoLoginID", m.getHm_id());
						autoLoginID.setMaxAge(1 * 60 * 60 * 24);
						res.addCookie(autoLoginID);
					}
					
				} else {
					req.setAttribute("result", "비번오류");
				}
			} else {
				req.setAttribute("result", "미가입ID");
			}
		} catch (Exception e) {
			req.setAttribute("result", "DB서버오류");
			e.printStackTrace();
		}
	}

	public void autologin(HttpServletRequest req, HttpServletResponse res) {
		Cookie[] cookies = req.getCookies();
		if (cookies != null) {
			for (Cookie c : cookies) {
				if (c.getName().equals("autoLoginID")) {
					String hm_id = c.getValue();
					if (hm_id != null && hm_id != "") {
						try {
							Member m = new Member(hm_id, null, null, null, null, null, null, null, null, null, null);
							Member mm = ss.getMapper(MemberMapper.class).getMemberByID(m);

							if (mm != null) {
								req.getSession().setAttribute("loginMember", mm);
								req.getSession().setMaxInactiveInterval(20 * 60);

							} else {
								req.setAttribute("result", "미가입 ID");
							}

						} catch (Exception e) {
							req.setAttribute("result", "DB서버 문제");

							e.printStackTrace();
						}
					}

				}

			}

		}

	}

	
}
