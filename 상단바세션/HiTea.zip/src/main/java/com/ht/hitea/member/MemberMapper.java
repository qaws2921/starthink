package com.ht.hitea.member;

public interface MemberMapper {
	
	public abstract Member getMemberByID(Member m);
	public abstract int join(Member m);
	public abstract Integer idCheckJson(Member m);
	public abstract Integer nicknameCheckJson(Member m);
	public abstract Integer emailCheckJson(Member m);
}
