function goHome() {
	location.href = "jc";	
}

function goLogo() {
	location.href = "goLogo";	
}


function goJoinOne() {
	location.href = "joinStepOneGo";	
}

function goJoinTwo() {
	location.href = "joinStepTwoGo";	
}

function goSearch() {
	location.href = "idpwSearchGo";	
}

function goMyPage() {
	location.href = "myPageGo";	
}

function goMyPageUpdatePwCheck() {
	location.href = "myPageUpdatePwCheckGo";
}

function goMyPageDeleteGo() {
	location.href = "memberDeleteGo";
}


function logout() {
	if (confirm("로그아웃?")) {
		location.href="logout.go";
	}
}



