package com.ht.hitea.member;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ht.hitea.sns.SNSDAO;

@Controller
public class MemberController {

	@Autowired
	private SNSDAO sDAO;
	
	@Autowired
	private MemberDAO mDAO;

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login(Member m, HttpServletRequest req, HttpServletResponse res) {
		mDAO.login(m, req, res);
		if (mDAO.loginCheck(req, res)) {
			sDAO.getAllSNS(req);
			req.setAttribute("contentPage", "sns/sns.jsp");
			return "index";
		} else {
			return "home";
		}
	}
	
	@RequestMapping(value = "/idCheckJson", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	public @ResponseBody int idCheckJson(Member m) {
		return mDAO.idCheckJson(m);
	}

	@RequestMapping(value = "/nicknameCheckJson", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	public @ResponseBody int nicknameCheckJson(Member m) {
		return mDAO.nicknameCheckJson(m);
	}

	@RequestMapping(value = "/emailCheckJson", method = RequestMethod.GET, produces = "application/json; charset=utf-8")
	public @ResponseBody int emailCheckJson(Member m) {
		return mDAO.emailCheckJson(m);
	}

	@RequestMapping(value = "/joinStepOneGo", method = RequestMethod.GET)
	public String joinOne(Member m, HttpServletRequest req, HttpServletResponse res) {
		mDAO.loginCheck(req, res);
		req.setAttribute("loginPage", "member/joinStepOne.jsp");
		return "home";
	}

	@RequestMapping(value = "/joinStepTwoGo", method = { RequestMethod.GET, RequestMethod.POST })
	public String joinTwoGo(Member m, HttpServletRequest req) {
		if (!"".equals(m.getHm_id())) {
			mDAO.joinInformation(m, req);
		}
		req.setAttribute("loginPage", "member/joinStepTwo.jsp");
		return "home";
	}

	@RequestMapping(value = "/joinStepThreeGo", method = RequestMethod.POST)
	public String joinTwo(Member m, HttpServletRequest req) {
		mDAO.joinInformation(m, req);
		req.setAttribute("loginPage", "member/joinStepThree.jsp");
		return "home";
	}

	@RequestMapping(value = "/joinStepFourGo", method = RequestMethod.POST)
	public String joinThreeStep(Member m, HttpServletRequest req, HttpServletResponse res) {
		boolean yn = mDAO.dateYN(m, req, res);
		if (yn) {
			req.setAttribute("loginPage", "member/joinStepFour.jsp");
			mDAO.join(m, req, res);
		} else {
			req.setAttribute("loginPage", "member/joinStepThree.jsp");
		}
		return "home";
	}



	
}
