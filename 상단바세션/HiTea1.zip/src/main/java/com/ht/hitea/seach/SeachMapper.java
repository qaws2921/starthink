package com.ht.hitea.seach;

import java.util.List;

import com.ht.hitea.Inquiry;
import com.ht.hitea.member.Member;

public interface SeachMapper {
	public abstract List<Member> memberSeach(Inquiry in);
	public abstract Integer memberSeachCount(Inquiry in);
	public abstract List<Member> memberSeachAll(Inquiry in);
}
