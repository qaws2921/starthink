package com.ht.hitea.seach;

import java.math.BigDecimal;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ht.hitea.Inquiry;
import com.ht.hitea.member.Member;
import com.ht.hitea.member.Members;



@Service
public class SeachDAO {

	@Autowired
	private SqlSession ss;
	
	public Members memberSeach(int page,String etseach,HttpServletRequest req) {
		Inquiry in = new Inquiry(null,null,etseach);
		int count2 = ss.getMapper(SeachMapper.class).memberSeachCount(in);
		double count = 4;
		int pageCount = (int) Math.ceil(count2 / count);
		if (count2>0) {
			int start = count2 - (page - 1) * (int) count;
			int end = (page == pageCount) ? 1 : start - ((int) count - 1);
			
			in.setStart(new BigDecimal(start));
			in.setEnd(new BigDecimal(end));
			
			List<Member> memberSeachs = ss.getMapper(SeachMapper.class).memberSeach(in);
			
			return new Members(memberSeachs);
		}
		return null;
	}
	
	public Integer memberSeachCount(String etseach) {
		Inquiry in = new Inquiry(null,null,etseach);
		return ss.getMapper(SeachMapper.class).memberSeachCount(in);
	}
}
