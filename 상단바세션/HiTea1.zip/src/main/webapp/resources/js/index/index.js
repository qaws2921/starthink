function loginPageClick() {
	
	var summon = false;
	
	$(".siteArrow").click(function() {
		
		if (!summon) {
		
			var img1 = $("<img>").attr("class", "memberMyVariousIcon").attr("src", "resources/img/index/circle.png");
			var img2 = $("<img>").attr("class", "memberMyVariousIcon").attr("src", "resources/img/index/circle.png");
			var img3 = $("<img>").attr("class", "memberMyVariousIcon").attr("src", "resources/img/index/circle.png");
			
			var td1_1 = $("<td></td>").append(img1);
			var td1_2 = $("<td></td>").append(img2);
			var td1_3 = $("<td></td>").append(img3);
			
			var td1 = $("<td></td>").text("내 페이지").attr("class", "memberMyPageTd");
			var td2 = $("<td></td>").text("문의하기").attr("class", "inquireTd");
			var td3 = $("<td></td>").text("로그아웃").attr("class", "memberLogoutTd");
			
			var tr1 = $("<tr></tr>").append(td1_1, td1);
			var tr2 = $("<tr></tr>").append(td1_2, td2);
			var tr3 = $("<tr></tr>").append(td1_3, td3);
			
			var table = $("<table></table>").append(tr1, tr2, tr3);
			
			$(".memberMyVarious").append(table);
		
		} else {
			$(".memberMyVarious").empty();
		}
		summon = !summon;
		
	});
}