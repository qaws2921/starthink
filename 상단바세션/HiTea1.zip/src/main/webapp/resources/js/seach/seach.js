
var page;
var login_sm_id;
function seachMemberShow() {
	login_sm_id = $("#et_login_hm_id").val();

	page = 1;
	
	seachMember(page);
	
	
	$(document).on("click",".gogo1",function(){
		page -= 1;
		seachMember(page);
	});

	$(document).on("click",".gogo2",function(){
		page += 1;
		seachMember(page);
	});


}

function a() {
	alert( $("#etseach").val());
	alert( $("#et_login_hm_id").val());
}

function seachMember(page) {
	var seach = $("#etseach").val();
	$("#ttd").empty();
	var teaTable2 = $("<table></table>").attr("id","teaTable2");
	var teaTr1 = $("<tr></tr>");

	var teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("Tea(0)");
	teaTr1.append(teaNameTd);
	teaTable2.append(teaTr1);
	$("#ttd").append(teaTable2);
	$.getJSON("seach.go.member?page="+page+"&etseach="+seach,function(data){
		$.getJSON("seach.go.member.count?etseach="+seach,function(data2){
			$("#ttd").empty();
		teaTable2 = $("<table></table>").attr("id","teaTable2");
		teaTr1 = $("<tr></tr>");
		memberCount = data2.member.length;
		teaNameTd = $("<td></td>").attr("id","teaNameTd").attr("align","left").attr("colspan","6").text("Tea("+data2+")");
		teaTr1.append(teaNameTd);
		///////////////////////////////////////
		
		var teaTr2 = $("<tr></tr>");
		var gogo1 = $("<span></span>").attr("class","gogo1").text("◀");
		if (page == 1) {
			gogo1.text("");
		}
		var memberPage1 = $("<td></td>").attr("id","memberPage1").append(gogo1);
		
		
		teaTr2.append(memberPage1);
		if (data.member.length == 4) {
			
			for (var i = 0; i < 4; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
		}else if (data.member.length == 3) {
			for (var i = 0; i < 3; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
			seachMemberBlockMake(teaTr2,teaTable2);
		}else if (data.member.length == 2) {
			for (var i = 0; i < 2; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			
			for (var i = 0; i < 2; i++) {
				seachMemberBlockMake(teaTr2,teaTable2);
			}
		}else if (data.member.length == 1) {
			for (var i = 0; i < 1; i++) {
				seachMemberMake(data.member[i],teaTr2,teaTable2);				
			}
			for (var i = 0; i < 3; i++) {
				seachMemberBlockMake(teaTr2,teaTable2);
			}
		}
		
		var gogo2 = $("<span></span>").attr("class","gogo2").text("▶");
		if (page*4 >= data2.member.length) {
			gogo2.text("");
		}
		var memberPage2 = $("<td></td>").attr("id","memberPage2").append(gogo2);
		
		
		
		teaTr2.append(memberPage2);
		teaTable2.append(teaTr1,teaTr2);
		
		
		$("#ttd").append(teaTable2);
		});
	});
}


function seachMemberMake(member,teaTr2,teaTable2) {
	var teasTd = $("<td></td>").attr("align","center");
	if (member.sm_id == login_sm_id) {
		var memberSTable = $("<table></table>").attr("onclick","goMyPage('"+login_sm_id+"');").attr("class","memberSTable");
	}else {
		var memberSTable = $("<table></table>").attr("onclick","goPage('"+member.sm_id+"');").attr("class","memberSTable");
		
	}
	
	
	if (member.sm_img == 'kakao.jpg') {
		var seachImg = $("<img></img>").attr("class","seachImg").attr("src","resources/baseImg/"+member.sm_img);
		var aseachImg = $("<a></a>").attr("href","resources/baseImg/"+member.sm_img).append(seachImg);
	}else {
		var seachImg = $("<img></img>").attr("class","seachImg").attr("src","resources/memberImg/"+member.sm_img);
		var aseachImg = $("<a></a>").attr("href","resources/memberImg/"+member.sm_img).append(seachImg);
	}
	var memberSTableImgTd = $("<td></td>").attr("align","center").append(aseachImg);
	var memberSTableImgTr = $("<tr></tr>").append(memberSTableImgTd);
	
	//////////////////////////////////////////////////
	
	var memberSTableIdTd = $("<td></td>").attr("align","center").text(member.sm_id);
	var memberSTableIdTr = $("<tr></tr>").append(memberSTableIdTd);
	
	///////////////////////////////////////////////
	
	var memberSTableNameTd = $("<td></td>").attr("align","center").text(member.sm_name);
	var memberSTableNameTr = $("<tr></tr>").append(memberSTableNameTd);
	
	memberSTable.append(memberSTableImgTr,memberSTableIdTr,memberSTableNameTr);
	
	teasTd.append(memberSTable);
	teaTr2.append(teasTd);
	teaTable2.append(teaTr2);
			
}
function seachMemberBlockMake(teaTr2,teaTable2) {
	
	var teasTd = $("<td></td>").attr("align","center");
	var memberSTable = $("<table></table>").attr("class","memberSTable2");
	

	var memberSTableImgTd = $("<td></td>").attr("align","center");
	var memberSTableImgTr = $("<tr></tr>").append(memberSTableImgTd);
	
	//////////////////////////////////////////////////
	
	var memberSTableIdTd = $("<td></td>").attr("align","center");
	var memberSTableIdTr = $("<tr></tr>").append(memberSTableIdTd);
	
	///////////////////////////////////////////////
	
	var memberSTableNameTd = $("<td></td>").attr("align","center");
	var memberSTableNameTr = $("<tr></tr>").append(memberSTableNameTd);
	
	memberSTable.append(memberSTableImgTr,memberSTableIdTr,memberSTableNameTr);
	
	teasTd.append(memberSTable);
	teaTr2.append(teasTd);
	teaTable2.append(teaTr2);
}


function seachSNS2(page) {
	var seach = $("#seach").val();
	var SNSSeachCountTd = $("#SNSSeachCountTd").text("SNS(0)");
	
	$.getJSON("seach.sns.all?seach="+seach,function(data2){
		SNSSeachCountTd.text("SNS("+data2.sns.length+")");
	});
	
}

function seachSNS(pNo) {
	var seach = $("#seach").val();
	var SNSSeachCountTd = $("#SNSSeachCountTd").text("SNS(0)");

	$.getJSON("seach.go.sns?page="+pNo+"&seach="+seach,function(data){
		$.getJSON("seach.sns.all?seach="+seach,function(data2){
		
			SNSSeachCountTd.text("SNS("+data2.sns.length+")");

			login_sm_id = $("#login_sm_id").val();
	
				$.each(data.sns,function(i1,s){
	
							if (s.st_img == 'kakao.jpg') {
								var homeSNSImg = $("<img></img>").attr("class","homeSNSImg").attr("src","resources/baseImg/"+s.st_img);
								var aHomeSNSImg = $("<a></a>").attr("href","resources/baseImg/"+s.st_img).append(homeSNSImg);
							}else {
								var homeSNSImg = $("<img></img>").attr("class","homeSNSImg").attr("src","resources/memberImg/"+s.st_img);
								var aHomeSNSImg = $("<a></a>").attr("href","resources/memberImg/"+s.st_img).append(homeSNSImg);
							}
							if (login_sm_id == s.st_id) {
								var st_id = $("<a></a>").attr("class","st_id").attr("style","cursor: pointer;").attr("onclick","goMyPage('"+login_sm_id+"');").text(s.st_id+"("+s.sm_name+")");
							}else {
								var st_id = $("<a></a>").attr("class","st_id2").attr("style","cursor: pointer;").attr("onclick","goPage('"+s.st_id+"');").text(s.st_id+"("+s.sm_name+")");	
							}
							var homeSNSIdTd = $("<td></td>").attr("align","left").attr("class","homeSNSIdTd").append(aHomeSNSImg,st_id);
							
							if (login_sm_id == s.st_id || login_sm_id == "koko2921") {
								var homeSNSButtonU = $("<button></button>").attr("class","homeSNSButton").attr("onclick","goSNSDetail('"+s.st_no+"',1,'"+s.st_txt+"')").text("수정");
								var homeSNSButtonD = $("<button></button>").attr("class","homeSNSButton").attr("onclick","goSNSDelete('"+s.st_no+"')").text("삭제");
							}else {
								var report = $("<img>").attr("src","resources/img/bulb.png").attr("class"," report").attr("onclick","reportClick('"+s.st_no+"','"+login_sm_id+"','"+"글"+"')");
								var homeSNSButtonU=$("<a></a>").append(report);
								var homeSNSButtonD=$("<a></a>");
							}
							var homeSNSUDButtonTd = $("<td></td>").attr("align","right").append(homeSNSButtonU,homeSNSButtonD);			
							var homeSNSTr = $("<tr></tr>").append(homeSNSIdTd,homeSNSUDButtonTd);
							/////////////////////////////////////////////////////
							
							var homeSNSHostTd = $("<td></td>").attr("align","left").attr("class","homeSNSHostTd").text(s.st_host);
							var homeSNSDate = $("<fmt:formatDate/>").attr("value",s.st_date).attr("pattern","yyyy/MM/dd (E) a hh:mm");
							var homeSNSDateTd = $("<td></td>").attr("align","right").attr("class","homeSNSDateTd").html(s.st_date.year+"년"+s.st_date.monthValue+"월"+s.st_date.dayOfMonth+"일 "+s.st_date.hour+"시"+s.st_date.minute+"분");
							var homeSNSHDTr = $("<tr></tr>").append(homeSNSHostTd,homeSNSDateTd);
							var homeSNSHDTable=  $("<table></table>").attr("style","border-spacing: 0px; width: 100%;").append(homeSNSHDTr);
							var UHomeSNSHDTd = $("<td></td>").attr("colspan","2").append(homeSNSHDTable);
							var UHomeSNSHDTr =$("<tr></tr>").append(UHomeSNSHDTd);
							//////////////////////////////////////////////////////
							
							if (s.st_photo !='photo' ) {
								var photo = $("<img></img>").attr("class","homeSNSPhoto").attr("src","resources/photo/"+s.st_photo);
								var aPhoto = $("<a></a>").attr("href","resources/photo/"+s.st_photo).append(photo);
							}else {
								var aPhoto = $("<a></a>");
							}
							var photoTd = $("<td></td>").attr("colspan","2").attr("align","center").append(aPhoto);
							var photoTr = $("<tr></tr>").append(photoTd);
							//////////////////////////////////////////////////
							
							var homeSNSTxtTd = $("<td></td>").attr("colspan","2").attr("align","left").attr("class","homeSNSTxtTd").html(s.st_txt);
							var homeSNSTxtTr = $("<tr></tr>").append(homeSNSTxtTd);
							/////////////////////////////////////////////////
							
							var homeSNSHashTd = $("<td></td>").attr("colspan","2").attr("align","left").attr("class","homeSNSHashTd");

							for (var x = 0; x < s.hash.length; x++) {
								var fHash = s.hash[x].shash_hash;
								if (fHash.charAt(0)=="#") {
									var hameSNSHashA = $("<a></a>").attr("href", "seach.go?seach="+s.hash[x].shash_hash.substring(1)).append(s.hash[x].shash_hash);
									var homeSNSHash = $("<span></span>").attr("class","homeHash").text(" ").append(hameSNSHashA);
									homeSNSHashTd.append(homeSNSHash);		
								}
							}
							var homeSNSHashTr = $("<tr></tr>").append(homeSNSHashTd);
							
							
						
							/////////////////////////////////////////////////
							var hartCheck = "hart.png";
							
							if ( s.hart != null) {
								for (var i = 0; i < s.hart.length; i++) {
									if (s.hart[i].sh_id ==  login_sm_id) {
										hartCheck = "hartok.png";
									}
								}
								
							}
							
							var hartImg =$("<img></img>").attr("class","hartImg").attr("src","resources/img/"+hartCheck);
							
							
							var hartNumber = $("<span></span>").attr("class","hartCount").text("("+s.hart.length+")");
							var hartInput = $("<input></input>").attr("class","hartInput").attr("type","hidden").attr("value",s.st_no);
							
							var hartTd = $("<td></td>").attr("class","hartTd").attr("colspan","2").attr("align","left").append(hartImg,hartNumber,hartInput);
							var hartTr = $("<tr></tr>").append(hartTd);
							/////////////////////////////////////////////////////////////////////
							if (login_sm_id != null) {
								
								var pageNo = $("<input></input>").attr("type","hidden").attr("value","1").attr("name","pageNo");
								var sc_st_no = $("<input></input>").attr("type","hidden").attr("value",s.st_no).attr("name","sc_st_no");
								var snsCommentId = $("<span></span>").text(login_sm_id);
								var sc_txt = $("<input></input>").attr("id","homeCommentInput").attr("maxlength","100").attr("name","sc_txt");
								var homeCommentButton = $("<button></button>").attr("id","homeCommentButton").text("쓰기");
								var commentForm = $("<form></form>").attr("action","sns.comment.reg").attr("onsubmit","return commentCheck(this)").append(pageNo,sc_st_no,snsCommentId,sc_txt,homeCommentButton);
							}else {
								var commentForm = $("<a></a>");
							}
							var homeCommentTd = $("<td></td>").attr("colspan","2").attr("id","homeCommentTd").append(commentForm);
							var homeCommentTr = $("<tr></tr>").append(homeCommentTd);
							
							///////////////////////////////////////////////////////
							
							var homeSNSTable = $("<table></table>").attr("class","homeSNSTable").append(homeSNSTr,UHomeSNSHDTr,photoTr,homeSNSTxtTr,homeSNSHashTr,hartTr,homeCommentTr);
							
							if (s.snscs != null) {
								
								for (var j = 0; j < s.snscs.length; j++) {
								
									var commentTd = $("<td></td>").attr("class","allCommentTd").attr("style","border-bottom:#263238 dotted 1px;").attr("colspan","2");
									
									if (s.snscs[j].st_img == 'kakao.jpg') {
										var homeSNSCommentImg = $("<img></img>").attr("class","homeSNSCommentImg").attr("src","resources/baseImg/"+s.snscs[j].sc_img);
										var aHomeSNSCommentImg = $("<a></a>").attr("href","resources/baseImg/"+s.snscs[j].sc_img).append(homeSNSCommentImg);
									}else {
										var homeSNSCommentImg = $("<img></img>").attr("class","homeSNSCommentImg").attr("src","resources/memberImg/"+s.snscs[j].sc_img);
										var aHomeSNSCommentImg = $("<a></a>").attr("href","resources/memberImg/"+s.snscs[j].sc_img).append(homeSNSCommentImg);
										
									}										
									
									var homeSNSCommentImgTd = $("<td></td>").append(aHomeSNSCommentImg);
									//////////////////////////////////////////////////////
									
									if (login_sm_id == s.snscs[j].sc_id) {
										var aHomeSNSCommentId = $("<a></a>").attr("style","cursor: pointer;").attr("onclick","goMyPage('"+login_sm_id+"');").text(s.snscs[j].sc_id);	
									}else {
										var aHomeSNSCommentId = $("<a></a>").attr("style","cursor: pointer;").attr("onclick","goPage('"+s.snscs[j].sc_id+"');").text(s.snscs[j].sc_id);	
										
									}
									var homeSNSCommentIdTd = $("<td></td>").attr("id","homeSNSCommentIdTd").append(aHomeSNSCommentId);
									
									///////////////////////////////////////////////////////
									
									var homeSNSCommentTxtSpan = $("<span></span>").text(s.snscs[j].sc_txt);
									var homeSNSCommentTxtTd = $("<td></td>").attr("id","homeSNSCommentTxtTd").append(homeSNSCommentTxtSpan);
									
									/////////////////////////////////////////////////////////////
									
									var homeSNSCommentDateTd = $("<td></td>").attr("id","homeSNSCommentDateTd").text(s.snscs[j].sc_date.year+"년"+s.snscs[j].sc_date.monthValue+"월"+s.snscs[j].sc_date.dayOfMonth+"일 "+s.snscs[j].sc_date.hour+"시"+s.snscs[j].sc_date.minute+"분");
									//////////////////////////////////////////////////
									
									
									if (login_sm_id == s.snscs[j].sc_id || login_sm_id == "koko2921") {
										var homeSNSCommentButtonU = $("<button></button>").attr("class","homeSNSCommentButton").attr("onclick","goSNSCommentUpdate('"+s.snscs[j].sc_no+"',1,)").text("수정");
										var homeSNSCommentButtonD = $("<button></button>").attr("class","homeSNSCommentButton").attr("onclick","goSNSCommentDelete('"+s.snscs[j].sc_no+"',1,)").text("삭제");
									}else {
										var homeSNSCommentButtonU=$("<a></a>");
										var homeSNSCommentButtonD=$("<a></a>");
									}
									var homeSNSCommentButtonTd = $("<td></td>").attr("id","homeSNSCommentButtonTd").append(homeSNSCommentButtonU,homeSNSCommentButtonD);			
									
									
									
									
									var homeSNSCommentTr = $("<tr></tr>").append(homeSNSCommentImgTd,homeSNSCommentIdTd,homeSNSCommentTxtTd,homeSNSCommentDateTd,homeSNSCommentButtonTd);
									var homeSNSCommentTable = $("<table></table>").attr("id","homeSNSCommentTable").append(homeSNSCommentTr);
									commentTd.append(homeSNSCommentTable);
									var commentTr = $("<tr></tr>").append(commentTd);
									homeSNSTable.append(commentTr);								
									
									

								}
							}else {
								
							}
							
					$("#SNSSeachTd").append(homeSNSTable);			
					
				});
		});

	});	
	
}



function hartImgClick() {
	$(document).on("click",".hartImg",function(){
		var hartImg = $(this);
		var hartCount = $(this).parent().find(".hartCount");
		var st_no2 = $(this).parent().find(".hartInput").val();
		var le = 0;
		$.getJSON("hart.check.img?st_no="+st_no2+"&st_id="+login_sm_id,function(data) {
			$.getJSON("hart.check?st_no="+st_no2,function(data3) {
				
				le = data.hart.length;
				if (le == 1) {	
					$.getJSON("hart.delete?st_no="+st_no2+"&st_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length-1;
						hartImg.attr("class","hartImg").attr("src","resources/img/hart.png");
						hartCount.empty();
						hartCount.text("("+num+")");
					});
				}else {
					$.getJSON("hart.reg?st_no="+st_no2+"&st_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length+1;
						hartImg.attr("class","hartImg").attr("src","resources/img/hartok.png");
						hartCount.empty();
						hartCount.text("("+num+")");
					});
				}
			});
		});
	}); 
}



function scrollSeachShow() {
	
	
	var pNo = 1;
	seachSNS(pNo);
	
	

	
	$(window).scroll(function() {
		var htmlHeight = $(document).height();
		var scrollBottom =$(window).scrollTop() + $(window).height();
		
		if (scrollBottom+1 >= htmlHeight) {
			pNo++;
			seachSNS(pNo);
			
		}
	});
}

function hartImgClick2() {
	$(document).on("click",".hartImg",function(){
		var hartImg = $(this);
		var hartCount = $(this).parent().find(".hartCount");
		var st_no2 = $(this).parent().find(".hartInput").val();
		var le = 0;
		$.getJSON("hart.check.img?st_no="+st_no2+"&st_id="+login_sm_id,function(data) {
			$.getJSON("hart.check?st_no="+st_no2,function(data3) {
				
				le = data.hart.length;
				if (le == 1) {	
					$.getJSON("hart.delete?st_no="+st_no2+"&st_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length-1;
						hartImg.attr("class","hartImg").attr("src","resources/img/hart.png");
						hartCount.empty();
						hartCount.text("("+num+")");
					});
				}else {
					$.getJSON("hart.reg?st_no="+st_no2+"&st_id="+login_sm_id,function(data2) {
						
						var num = data3.hart.length+1;
						hartImg.attr("class","hartImg").attr("src","resources/img/hartok.png");
						hartCount.empty();
						hartCount.text("("+num+")");
					});
				}
			});
		});
	}); 
}



