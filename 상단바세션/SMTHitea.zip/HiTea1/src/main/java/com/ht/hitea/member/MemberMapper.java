package com.ht.hitea.member;

public interface MemberMapper {
	
	public abstract Member getMemberByID(Member m);
	public abstract int join(Member m);
	
	public abstract Integer idCheckJson(Member m);
	public abstract Integer nicknameCheckJson(Member m);
	public abstract Integer emailCheckJson(Member m);
	
	public abstract Member idSearch(Member m);
	public abstract int pwSearch(Member m);
	public abstract Member temporarilyPwEmail(Member m);	
	
	public abstract Integer memberUpdatePwCheck(Member m);
	public abstract Integer memberUpdate(Member m);
	public abstract Integer memberDelete(Member m);
	
	public abstract Member yourPageInformation(Member m);
	
}
