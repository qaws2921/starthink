$(function() {
	
	var today = new Date();
	var yf = today.getFullYear();
	
	for (var i = 1975; i <= yf-1; i++) {
		$(".birthdayY").append("<option value='"+i+"'>"+i+"</option>");
	}
	
	for (var i = 1; i <= 12; i++) {
		$(".birthdayM").append("<option value='"+i+"'>"+i+"</option>");
	}
	
	for (var i = 1; i <= 31; i++) {
		$(".birthdayD").append("<option value='"+i+"'>"+i+"</option>");
	} 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	var EAddress = ['gmail.com', 'naver.com', 'nate.com', 'hanmail.net', 'yahoo.co.kr', 'freechal.com', 'paran.com', '직접입력'];
	
	$.each(EAddress,function(i, e) {
		$(".emailAddress").append("<option value='"+e+"'>"+EAddress[i]+"</option>");
		
	});
	
	$(".emailAddress").change();
			
	$(".emailAddress").change(function() {
		if ($(this).val() == "직접입력") {
			if($(".type").val() == "1"){
				$('#emailAddress').val($('.emailAddress2').val());
			}
			
			$(".emailDirectInput").attr('type','text');

		}else{
			$(".emailDirectInput").attr('type','hidden');
		}
	}); 
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	var question = ['생년월일?', '1~9까지 좋아하는 숫자?', '자주쓰는 핸드폰 뒷자리?', '자신의 보물 제1호는?', '아버지의 성함은?', '어머니의 성함은?', '형제는 몇명?', '처음해본 게임은?', '학창시절 별명은?', '좋아하는 색깔은?'];	

	$.each(question,function(i, e) {
		$(".pwQuestion").append("<option value='"+e+"'>"+question[i]+"</option>");
	});

	
});

 		