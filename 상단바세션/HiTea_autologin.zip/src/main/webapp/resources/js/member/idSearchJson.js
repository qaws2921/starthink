$(function() {

	$(".idSearch").click(
			function() {
				var hm_name = $(".hm_name").val();
				var hm_email = $(".hm_email").val();
				// alert(hm_name);
				// alert(hm_email);

				url = "http://localhost/test/idSearchJson?hm_name=" + hm_name
						+ "&hm_email=" + hm_email;
				$.getJSON(url, function(data) {
					// alert(JSON.stringify(data));
					$.each(data.member, function(i, s) {
						alert(s.hm_id);
					});
				});
			});

});

