$(function() {
	$(".hm_id").keyup(function() {
		var id = $(".hm_id").val();
		$.ajax({
			url : "idCheckJson",
			data : {
				hm_id : id
			},
			success : function(data) {
				if (data == 1) {
					$(".idCheck").text("사용하고 있는 중이거나 탈퇴한 아이디 입니다.");
				} else if (data == 0) {
					$(".idCheck").text("");
				}

			}
		});
	});

	$(".hm_nickname").keyup(function() {
		var nickname = $(".hm_nickname").val();
		$.ajax({
			url : "nicknameCheckJson",
			data : {
				hm_nickname : nickname
			},
			success : function(data) {
				if (data == 1) {
					$(".nicknameCheck").text("사용하고 있는 중이거나 탈퇴한 닉네임 입니다.");
				} else if (data == 0) {
					$(".nicknameCheck").text("");
				}

			}
		});
	});

	$(".emailAddress").change(function() {
		var emailId = $(".emailId").val();
		var emailAddress = $(".emailAddress option:selected").val();
		var emailDirectInput = null;
		var email = null;

		if (emailAddress == '직접입력') {
			$(".emailDirectInput").keyup(function() {
				emailDirectInput = $(".emailDirectInput").val();
				email = emailId + "@" + emailDirectInput;
				emailAJAX(email);
			});
		} else {
			$(".emailDirectInput").val("");
			email = emailId + "@" + emailAddress;
			emailAJAX(email);
		}
	});
});

function emailAJAX(email) {
	$.ajax({
		url : "emailCheckJson",
		data : {hm_email : email}, 
		success : function(data) {
				//	alert(data);
			if (data == 1) {
				$(".emailCheck").text("사용하고 있는 중이거나 탈퇴한 이메일 입니다.");						
			} else if (data == 0) {
				$(".emailCheck").text("");
			}
		
		}
	});
}